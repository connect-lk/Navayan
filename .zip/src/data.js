// src/data/navbarData.js
export const navbarData = {
  logo: {
    src: "/images/logo.png",
    link: "/", 
    alt: "Navayan Logo",
  },
  disclaimerlinks: {
    text: "Disclaimer",
    href: "/disclaimer",
  },

  report_button: {
    text: "Report an Issue",
  },
};

 

export const homePageData = {
  banner: {
    image: "/images/home1.png",
    alt: "A happy family jumping for joy in a park",
  },
  heading: "Available Projects",
  button: {
    text: "Add Booking",
    link: "/booking",
  },
  projects: [
    {
      projectName: "Navayan's Capital Park",
      total: 150,
      image: "/images/project_card.png",
      available: 35,
      onHold: 20,
      booked: 10,
    },
    {
      projectName: "Navayan's West Gate",
      total: 150,
      image: "/images/project_card.png",
      available: 35,
      onHold: 20,
      booked: 10,
    },
    {
      projectName: "Navayan's East Enclave",
      total: 200,
      image: "/images/project_card.png",
      available: 60,
      onHold: 25,
      booked: 15,
    },
    {
      projectName: "Navayan's Capital Park",
      total: 150,
      image: "/images/project_card.png",
      available: 35,
      onHold: 20,
      booked: 10,
    },
    {
      projectName: "Navayan's West Gate",
      total: 150,
      image: "/images/project_card.png",
      available: 35,
      onHold: 20,
      booked: 10,
    },
    {
      projectName: "Navayan's East Enclave",
      total: 200,
      image: "/images/project_card.png",
      available: 60,
      onHold: 25,
      booked: 15,
    },
  ],
};

export const bookingData = {
  heading: "NEW BOOKING",
  inventoryHeading: "Inventory",
  searchPlaceholder: "Search unit",
  projects: [
    {
      projectName: "Navayan's Capital Park",
      project_subtitle: "Property Details",
      total: 150,
      image: "/images/project_card.png",
      available: 35,
      onHold: 20,
      booked: 10,
    },
  ],
  table: {
    kycTable: false,
    BookingTableData: [
      {
        sn: 1,
        unitNo: "S1",
        plotSize: "1500 sq.ft.",
        plotFacing: "North",
        plc: "Garden",
        cost: "₹ 7,50,000",
        addCost: "₹ 50,000",
        status: "Available",
        booked: false,
      },
      {
        sn: 1,
        unitNo: "S1",
        plotSize: "1500 sq.ft.",
        plotFacing: "North",
        plc: "Garden",
        cost: "₹ 7,50,000",
        addCost: "₹ 50,000",
        status: "Available",
        booked: false,
      },
      {
        sn: 2,
        unitNo: "S2",
        plotSize: "1000 sq.ft.",
        plotFacing: "East",
        plc: "Corner",
        cost: "₹ 5,00,000",
        addCost: "₹ 50,000",
        status: "Booked",
        booked: true,
      },
      {
        sn: 2,
        unitNo: "S2",
        plotSize: "1000 sq.ft.",
        plotFacing: "East",
        plc: "Corner",
        cost: "₹ 5,00,000",
        addCost: "₹ 50,000",
        status: "Booked",
        booked: true,
      },
      {
        sn: 2,
        unitNo: "S2",
        plotSize: "1000 sq.ft.",
        plotFacing: "East",
        plc: "Corner",
        cost: "₹ 5,00,000",
        addCost: "₹ 50,000",
        status: "Booked",
        booked: true,
      },
      {
        sn: 2,
        unitNo: "S2",
        plotSize: "1000 sq.ft.",
        plotFacing: "East",
        plc: "Corner",
        cost: "₹ 5,00,000",
        addCost: "₹ 50,000",
        status: "Booked",
        booked: true,
      },
      {
        sn: 1,
        unitNo: "S1",
        plotSize: "1500 sq.ft.",
        plotFacing: "North",
        plc: "Garden",
        cost: "₹ 7,50,000",
        addCost: "₹ 50,000",
        status: "Available",
        booked: false,
      },
      {
        sn: 2,
        unitNo: "S2",
        plotSize: "1000 sq.ft.",
        plotFacing: "East",
        plc: "Corner",
        cost: "₹ 5,00,000",
        addCost: "₹ 50,000",
        status: "Booked",
        booked: true,
      },
      {
        sn: 2,
        unitNo: "S2",
        plotSize: "1000 sq.ft.",
        plotFacing: "East",
        plc: "Corner",
        cost: "₹ 5,00,000",
        addCost: "₹ 50,000",
        status: "Booked",
        booked: true,
      },
      {
        sn: 1,
        unitNo: "S1",
        plotSize: "1500 sq.ft.",
        plotFacing: "North",
        plc: "Garden",
        cost: "₹ 7,50,000",
        addCost: "₹ 50,000",
        status: "Available",
        booked: false,
      },
      {
        sn: 1,
        unitNo: "S1",
        plotSize: "1500 sq.ft.",
        plotFacing: "North",
        plc: "Garden",
        cost: "₹ 7,50,000",
        addCost: "₹ 50,000",
        status: "Available",
        booked: false,
      },
    ],
  },
};

export const bookingProjects = [
  {
    projectName: "Navayan's Capital Park",
    total: 150,
    available: 35,
    onHold: 20,
    booked: 10,
  },
];
export const applicantFields = [
  {
    name: "applicantName",
    placeholder: "Full Name of Applicant",
    type: "text",
  },
  { name: "applicantCof", placeholder: "C/o of", type: "text" },
  {
    name: "applicantPhone",
    placeholder: "Phone No. of Applicant",
    type: "tel",
  },
  {
    name: "applicantAdditionalPhone",
    placeholder: "Additional No. of Applicant",
    type: "tel",
  },
  {
    name: "applicantEmail",
    placeholder: "Email Id of Applicant",
    type: "email",
  },
  {
    name: "applicantAddress",
    placeholder: "Permanent Address of Applicant",
    type: "textarea",
  },
  {
    name: "applicantAadhar",
    placeholder: "Aadhar No. of Applicant",
    type: "text",
  },
  { name: "applicantPan", placeholder: "PAN No. of Applicant", type: "text" },
  { name: "applicantDob", placeholder: "Date of Birth", type: "date" },
  {
    name: "applicantProfession",
    placeholder: "Profession of Applicant",
    type: "text",
  },
];

export const coApplicantFields = [
  { name: "coApplicantName", placeholder: "Full Name", type: "text" },
  { name: "coApplicantCof", placeholder: "C/o of", type: "text" },
  { name: "coApplicantPhone", placeholder: "Phone No.", type: "tel" },
  {
    name: "coApplicantAdditionalPhone",
    placeholder: "Additional No.",
    type: "tel",
  },
  { name: "coApplicantEmail", placeholder: "Email Id", type: "email" },
  {
    name: "coApplicantAddress",
    placeholder: "Permanent Address",
    type: "textarea",
  },
  { name: "coApplicantAadhar", placeholder: "Aadhar No.", type: "text" },
  { name: "coApplicantPan", placeholder: "PAN No.", type: "text" },
  { name: "coApplicantDob", placeholder: "Date of Birth", type: "date" },
  { name: "coApplicantProfession", placeholder: "Profession", type: "text" },
];

export const applicantData = {
  "Full Name of Applicant": "Example Name",
  "C/o of": "Example Text",
  "Phone No. of Applicant": "7895289625",
  "Additional No. of Applicant": "2368896488",
  "Email Id of Applicant": "Example@gmail.com",
  "Permanent Address of Applicant":
    "123, this is the example address, city name, state, pincode et cetera",
  "Aadhar No. of Applicant": "85598568925745852",
  "PAN No. of Applicant": "HBUBB8857",
  DOB: "08/11/1990",
  "Profession of Applicant": "Example Text",
};

export const applicantAutoFillData = {
  applicantAadhar: "496895208976",
  applicantAdditionalPhone: "8107545771",
  applicantAddress: "hello world",
  applicantCof: "abcd",
  applicantDob: "2025-09-18",
  applicantEmail: "abcd@gmail.com",
  applicantName: "sonu kumar saini",
  applicantPan: "56Ad67HJ",
  applicantPhone: "08107545771",
  applicantProfession: "acbd",
};
