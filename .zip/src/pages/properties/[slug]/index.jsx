"use client";
import { IoSearchOutline } from "react-icons/io5";
import React, { useEffect, useState } from "react";
import { NewBookingCard } from "@/components/comman/NewBookingCard";
import InventoryTable from "@/components/comman/InventoryTable";
import { bookingData } from "@/data";
import AllPages from "@/service/allPages";
import { useRouter } from "next/router";

const index = () => {
  const [inventoryList, setInventoryList] = useState([]);
  const [searchText, setSearchText] = useState(""); // <-- Add search state

  const router = useRouter();
  const { slug } = router.query; // get slug from URL
  const [project, setProject] = useState(null);
  const [loading, setLoading] = useState(false);

  const fetchProject = async () => {
    if (!slug) return;
    try {
      setLoading(true);
      const allProjects = await AllPages.properties();
      const matchedProject = allProjects.find((p) => p.slug === slug);
      setProject(matchedProject);
    } catch (error) {
      console.error("Error fetching project:", error);
      setProject([]);
      setLoading(false);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProject();
  }, [slug]);

  const InventoryListApiFun = async () => {
    try {
      const response = await AllPages.inventoryList(41);
      setInventoryList(response?.data);
      console.log("response",response?.data[0])
    } catch (error) {
      console.error("Error fetching inventory list:", error);
    }
  };

  useEffect(() => {
    InventoryListApiFun();
  }, []);

  const holdFlatFun = async (id) => {
    try {
      await AllPages.holdFlat(id); 
    } catch (error) {
      console.error("Error holding flat:", error.message);
    }
  };

  const tableData =
    inventoryList?.map((item, index) => ({
      id: item?.id,
      sn: index + 1,
      plotNo: item?.plot_no,
      plotSize: `${item?.plot_size} sq.ft`,
      plotFacing: item?.facing,
      plcSide: item?.plc_side,
      plcPercentage: `${item?.plc_percentage}%`,
      north: item?.north,
      south: item?.south,
      east: item?.east,
      west: item?.west,
      withPlc: `₹${item?.with_plc}`,
      additional: `₹${item?.additional}`,
      total: `₹${item?.total}`,
      status: item?.status,
      hold_expires_at:item?.hold_expires_at,
      created_at:item?.created_at,
      booked: item?.status?.toLowerCase() !== "available",
    })) || [];

  // Filter based on searchText
  const filteredData = tableData?.filter((item) =>
    item?.plotNo?.toLowerCase().includes(searchText?.toLowerCase())
  );

  return (
    <div className="max-w-screen-2xl mx-auto pb-16 px-6 min-h-screen   md:px-8 lg:px-12 2xl:px-0 ">
      {loading ? (
        <div className="flex justify-center items-center gap-6 h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#066FA9]"></div>
          <span className="ml-3 text-lg">Loading property...</span>
        </div>
      ) : (
        <>
          <div className="max-w-screen-2xl mx-auto pt-12">
            <h2 className="text-center justify-start text-neutral-900 md:text-3xl text-2xl font-bold leading-7 md:my-8 my-6">
              {bookingData?.heading}
            </h2>
            <div className="grid grid-cols-1 w-full items-center md:items-stretch justify-center xl:gap-8 gap-4">
              <NewBookingCard
                project_subtitle={"Property Details"}
                url={project?.acf?.property_image?.url}
                projectName={project?.title?.rendered}
                total={project?.flats_available?.total}
                available={project?.flats_available?.available}
                onHold={project?.flats_available?.hold}
                booked={project?.flats_available?.booked}
                slug={project?.slug}
              />
            </div>
          </div>
          <div className="w-full py-4">
            <div className="flex flex-col sm:flex-row items-center justify-between ">
              <h1 className="text-2xl md:text-[28px] font-bold text-gray-800 mb-4 sm:mb-0 md:block hidden">
                {bookingData?.inventoryHeading}
              </h1>

              <div className="w-full sm:w-80">
                <div className="relative flex items-center bg-white rounded-xl  ">
                  <input
                    type="text"
                    placeholder={bookingData?.searchPlaceholder}
                    className="w-full py-3.5 pl-4 pr-10 text-sm text-gray-700 font-[600] placeholder-gray-500 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#066fa9]"
                    value={searchText} // <-- Bind value
                    onChange={(e) => setSearchText(e.target.value)} // <-- Handle change
                  />
                  <IoSearchOutline className="absolute right-3 w-5 h-5 font-[900] text-gray-500" />
                </div>
              </div>
            </div>
          </div>
          <InventoryTable
            tableData={filteredData}
            holdFlatFun={holdFlatFun}
            InventoryListApiFun={InventoryListApiFun}
            slug={slug}
          />
        </>
      )}
    </div>
  );
};

export default index;
