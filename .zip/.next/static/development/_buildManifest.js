self.__BUILD_MANIFEST = {
  "/properties/[slug]": [
    "./static/chunks/pages/properties/[slug].js"
  ],
  "/properties/[slug]/bookingproperties/[bookingId]": [
    "./static/chunks/pages/properties/[slug]/bookingproperties/[bookingId].js"
  ],
  "__rewrites": {
    "afterFiles": [],
    "beforeFiles": [],
    "fallback": []
  },
  "sortedPages": [
    "/",
    "/404",
    "/_app",
    "/_error",
    "/api/hello",
    "/api/proxy",
    "/properties/[slug]",
    "/properties/[slug]/bookingproperties/[bookingId]"
  ]
};self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB()