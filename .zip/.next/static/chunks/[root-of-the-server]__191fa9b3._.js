(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[turbopack]/browser/dev/hmr-client/hmr-client.ts [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/// <reference path="../../../shared/runtime-types.d.ts" />
/// <reference path="../../runtime/base/dev-globals.d.ts" />
/// <reference path="../../runtime/base/dev-protocol.d.ts" />
/// <reference path="../../runtime/base/dev-extensions.ts" />
__turbopack_context__.s([
    "connect",
    ()=>connect,
    "setHooks",
    ()=>setHooks,
    "subscribeToUpdate",
    ()=>subscribeToUpdate
]);
function connect(param) {
    let { addMessageListener, sendMessage, onUpdateError = console.error } = param;
    addMessageListener((msg)=>{
        switch(msg.type){
            case 'turbopack-connected':
                handleSocketConnected(sendMessage);
                break;
            default:
                try {
                    if (Array.isArray(msg.data)) {
                        for(let i = 0; i < msg.data.length; i++){
                            handleSocketMessage(msg.data[i]);
                        }
                    } else {
                        handleSocketMessage(msg.data);
                    }
                    applyAggregatedUpdates();
                } catch (e) {
                    console.warn('[Fast Refresh] performing full reload\n\n' + "Fast Refresh will perform a full reload when you edit a file that's imported by modules outside of the React rendering tree.\n" + 'You might have a file which exports a React component but also exports a value that is imported by a non-React component file.\n' + 'Consider migrating the non-React component export to a separate file and importing it into both files.\n\n' + 'It is also possible the parent component of the component you edited is a class component, which disables Fast Refresh.\n' + 'Fast Refresh requires at least one parent function component in your React tree.');
                    onUpdateError(e);
                    location.reload();
                }
                break;
        }
    });
    const queued = globalThis.TURBOPACK_CHUNK_UPDATE_LISTENERS;
    if (queued != null && !Array.isArray(queued)) {
        throw new Error('A separate HMR handler was already registered');
    }
    globalThis.TURBOPACK_CHUNK_UPDATE_LISTENERS = {
        push: (param)=>{
            let [chunkPath, callback] = param;
            subscribeToChunkUpdate(chunkPath, sendMessage, callback);
        }
    };
    if (Array.isArray(queued)) {
        for (const [chunkPath, callback] of queued){
            subscribeToChunkUpdate(chunkPath, sendMessage, callback);
        }
    }
}
const updateCallbackSets = new Map();
function sendJSON(sendMessage, message) {
    sendMessage(JSON.stringify(message));
}
function resourceKey(resource) {
    return JSON.stringify({
        path: resource.path,
        headers: resource.headers || null
    });
}
function subscribeToUpdates(sendMessage, resource) {
    sendJSON(sendMessage, {
        type: 'turbopack-subscribe',
        ...resource
    });
    return ()=>{
        sendJSON(sendMessage, {
            type: 'turbopack-unsubscribe',
            ...resource
        });
    };
}
function handleSocketConnected(sendMessage) {
    for (const key of updateCallbackSets.keys()){
        subscribeToUpdates(sendMessage, JSON.parse(key));
    }
}
// we aggregate all pending updates until the issues are resolved
const chunkListsWithPendingUpdates = new Map();
function aggregateUpdates(msg) {
    const key = resourceKey(msg.resource);
    let aggregated = chunkListsWithPendingUpdates.get(key);
    if (aggregated) {
        aggregated.instruction = mergeChunkListUpdates(aggregated.instruction, msg.instruction);
    } else {
        chunkListsWithPendingUpdates.set(key, msg);
    }
}
function applyAggregatedUpdates() {
    if (chunkListsWithPendingUpdates.size === 0) return;
    hooks.beforeRefresh();
    for (const msg of chunkListsWithPendingUpdates.values()){
        triggerUpdate(msg);
    }
    chunkListsWithPendingUpdates.clear();
    finalizeUpdate();
}
function mergeChunkListUpdates(updateA, updateB) {
    let chunks;
    if (updateA.chunks != null) {
        if (updateB.chunks == null) {
            chunks = updateA.chunks;
        } else {
            chunks = mergeChunkListChunks(updateA.chunks, updateB.chunks);
        }
    } else if (updateB.chunks != null) {
        chunks = updateB.chunks;
    }
    let merged;
    if (updateA.merged != null) {
        if (updateB.merged == null) {
            merged = updateA.merged;
        } else {
            // Since `merged` is an array of updates, we need to merge them all into
            // one, consistent update.
            // Since there can only be `EcmascriptMergeUpdates` in the array, there is
            // no need to key on the `type` field.
            let update = updateA.merged[0];
            for(let i = 1; i < updateA.merged.length; i++){
                update = mergeChunkListEcmascriptMergedUpdates(update, updateA.merged[i]);
            }
            for(let i = 0; i < updateB.merged.length; i++){
                update = mergeChunkListEcmascriptMergedUpdates(update, updateB.merged[i]);
            }
            merged = [
                update
            ];
        }
    } else if (updateB.merged != null) {
        merged = updateB.merged;
    }
    return {
        type: 'ChunkListUpdate',
        chunks,
        merged
    };
}
function mergeChunkListChunks(chunksA, chunksB) {
    const chunks = {};
    for (const [chunkPath, chunkUpdateA] of Object.entries(chunksA)){
        const chunkUpdateB = chunksB[chunkPath];
        if (chunkUpdateB != null) {
            const mergedUpdate = mergeChunkUpdates(chunkUpdateA, chunkUpdateB);
            if (mergedUpdate != null) {
                chunks[chunkPath] = mergedUpdate;
            }
        } else {
            chunks[chunkPath] = chunkUpdateA;
        }
    }
    for (const [chunkPath, chunkUpdateB] of Object.entries(chunksB)){
        if (chunks[chunkPath] == null) {
            chunks[chunkPath] = chunkUpdateB;
        }
    }
    return chunks;
}
function mergeChunkUpdates(updateA, updateB) {
    if (updateA.type === 'added' && updateB.type === 'deleted' || updateA.type === 'deleted' && updateB.type === 'added') {
        return undefined;
    }
    if (updateA.type === 'partial') {
        invariant(updateA.instruction, 'Partial updates are unsupported');
    }
    if (updateB.type === 'partial') {
        invariant(updateB.instruction, 'Partial updates are unsupported');
    }
    return undefined;
}
function mergeChunkListEcmascriptMergedUpdates(mergedA, mergedB) {
    const entries = mergeEcmascriptChunkEntries(mergedA.entries, mergedB.entries);
    const chunks = mergeEcmascriptChunksUpdates(mergedA.chunks, mergedB.chunks);
    return {
        type: 'EcmascriptMergedUpdate',
        entries,
        chunks
    };
}
function mergeEcmascriptChunkEntries(entriesA, entriesB) {
    return {
        ...entriesA,
        ...entriesB
    };
}
function mergeEcmascriptChunksUpdates(chunksA, chunksB) {
    if (chunksA == null) {
        return chunksB;
    }
    if (chunksB == null) {
        return chunksA;
    }
    const chunks = {};
    for (const [chunkPath, chunkUpdateA] of Object.entries(chunksA)){
        const chunkUpdateB = chunksB[chunkPath];
        if (chunkUpdateB != null) {
            const mergedUpdate = mergeEcmascriptChunkUpdates(chunkUpdateA, chunkUpdateB);
            if (mergedUpdate != null) {
                chunks[chunkPath] = mergedUpdate;
            }
        } else {
            chunks[chunkPath] = chunkUpdateA;
        }
    }
    for (const [chunkPath, chunkUpdateB] of Object.entries(chunksB)){
        if (chunks[chunkPath] == null) {
            chunks[chunkPath] = chunkUpdateB;
        }
    }
    if (Object.keys(chunks).length === 0) {
        return undefined;
    }
    return chunks;
}
function mergeEcmascriptChunkUpdates(updateA, updateB) {
    if (updateA.type === 'added' && updateB.type === 'deleted') {
        // These two completely cancel each other out.
        return undefined;
    }
    if (updateA.type === 'deleted' && updateB.type === 'added') {
        const added = [];
        const deleted = [];
        var _updateA_modules;
        const deletedModules = new Set((_updateA_modules = updateA.modules) !== null && _updateA_modules !== void 0 ? _updateA_modules : []);
        var _updateB_modules;
        const addedModules = new Set((_updateB_modules = updateB.modules) !== null && _updateB_modules !== void 0 ? _updateB_modules : []);
        for (const moduleId of addedModules){
            if (!deletedModules.has(moduleId)) {
                added.push(moduleId);
            }
        }
        for (const moduleId of deletedModules){
            if (!addedModules.has(moduleId)) {
                deleted.push(moduleId);
            }
        }
        if (added.length === 0 && deleted.length === 0) {
            return undefined;
        }
        return {
            type: 'partial',
            added,
            deleted
        };
    }
    if (updateA.type === 'partial' && updateB.type === 'partial') {
        var _updateA_added, _updateB_added;
        const added = new Set([
            ...(_updateA_added = updateA.added) !== null && _updateA_added !== void 0 ? _updateA_added : [],
            ...(_updateB_added = updateB.added) !== null && _updateB_added !== void 0 ? _updateB_added : []
        ]);
        var _updateA_deleted, _updateB_deleted;
        const deleted = new Set([
            ...(_updateA_deleted = updateA.deleted) !== null && _updateA_deleted !== void 0 ? _updateA_deleted : [],
            ...(_updateB_deleted = updateB.deleted) !== null && _updateB_deleted !== void 0 ? _updateB_deleted : []
        ]);
        if (updateB.added != null) {
            for (const moduleId of updateB.added){
                deleted.delete(moduleId);
            }
        }
        if (updateB.deleted != null) {
            for (const moduleId of updateB.deleted){
                added.delete(moduleId);
            }
        }
        return {
            type: 'partial',
            added: [
                ...added
            ],
            deleted: [
                ...deleted
            ]
        };
    }
    if (updateA.type === 'added' && updateB.type === 'partial') {
        var _updateA_modules1, _updateB_added1;
        const modules = new Set([
            ...(_updateA_modules1 = updateA.modules) !== null && _updateA_modules1 !== void 0 ? _updateA_modules1 : [],
            ...(_updateB_added1 = updateB.added) !== null && _updateB_added1 !== void 0 ? _updateB_added1 : []
        ]);
        var _updateB_deleted1;
        for (const moduleId of (_updateB_deleted1 = updateB.deleted) !== null && _updateB_deleted1 !== void 0 ? _updateB_deleted1 : []){
            modules.delete(moduleId);
        }
        return {
            type: 'added',
            modules: [
                ...modules
            ]
        };
    }
    if (updateA.type === 'partial' && updateB.type === 'deleted') {
        var _updateB_modules1;
        // We could eagerly return `updateB` here, but this would potentially be
        // incorrect if `updateA` has added modules.
        const modules = new Set((_updateB_modules1 = updateB.modules) !== null && _updateB_modules1 !== void 0 ? _updateB_modules1 : []);
        if (updateA.added != null) {
            for (const moduleId of updateA.added){
                modules.delete(moduleId);
            }
        }
        return {
            type: 'deleted',
            modules: [
                ...modules
            ]
        };
    }
    // Any other update combination is invalid.
    return undefined;
}
function invariant(_, message) {
    throw new Error("Invariant: ".concat(message));
}
const CRITICAL = [
    'bug',
    'error',
    'fatal'
];
function compareByList(list, a, b) {
    const aI = list.indexOf(a) + 1 || list.length;
    const bI = list.indexOf(b) + 1 || list.length;
    return aI - bI;
}
const chunksWithIssues = new Map();
function emitIssues() {
    const issues = [];
    const deduplicationSet = new Set();
    for (const [_, chunkIssues] of chunksWithIssues){
        for (const chunkIssue of chunkIssues){
            if (deduplicationSet.has(chunkIssue.formatted)) continue;
            issues.push(chunkIssue);
            deduplicationSet.add(chunkIssue.formatted);
        }
    }
    sortIssues(issues);
    hooks.issues(issues);
}
function handleIssues(msg) {
    const key = resourceKey(msg.resource);
    let hasCriticalIssues = false;
    for (const issue of msg.issues){
        if (CRITICAL.includes(issue.severity)) {
            hasCriticalIssues = true;
        }
    }
    if (msg.issues.length > 0) {
        chunksWithIssues.set(key, msg.issues);
    } else if (chunksWithIssues.has(key)) {
        chunksWithIssues.delete(key);
    }
    emitIssues();
    return hasCriticalIssues;
}
const SEVERITY_ORDER = [
    'bug',
    'fatal',
    'error',
    'warning',
    'info',
    'log'
];
const CATEGORY_ORDER = [
    'parse',
    'resolve',
    'code generation',
    'rendering',
    'typescript',
    'other'
];
function sortIssues(issues) {
    issues.sort((a, b)=>{
        const first = compareByList(SEVERITY_ORDER, a.severity, b.severity);
        if (first !== 0) return first;
        return compareByList(CATEGORY_ORDER, a.category, b.category);
    });
}
const hooks = {
    beforeRefresh: ()=>{},
    refresh: ()=>{},
    buildOk: ()=>{},
    issues: (_issues)=>{}
};
function setHooks(newHooks) {
    Object.assign(hooks, newHooks);
}
function handleSocketMessage(msg) {
    sortIssues(msg.issues);
    handleIssues(msg);
    switch(msg.type){
        case 'issues':
            break;
        case 'partial':
            // aggregate updates
            aggregateUpdates(msg);
            break;
        default:
            // run single update
            const runHooks = chunkListsWithPendingUpdates.size === 0;
            if (runHooks) hooks.beforeRefresh();
            triggerUpdate(msg);
            if (runHooks) finalizeUpdate();
            break;
    }
}
function finalizeUpdate() {
    hooks.refresh();
    hooks.buildOk();
    // This is used by the Next.js integration test suite to notify it when HMR
    // updates have been completed.
    // TODO: Only run this in test environments (gate by `process.env.__NEXT_TEST_MODE`)
    if (globalThis.__NEXT_HMR_CB) {
        globalThis.__NEXT_HMR_CB();
        globalThis.__NEXT_HMR_CB = null;
    }
}
function subscribeToChunkUpdate(chunkListPath, sendMessage, callback) {
    return subscribeToUpdate({
        path: chunkListPath
    }, sendMessage, callback);
}
function subscribeToUpdate(resource, sendMessage, callback) {
    const key = resourceKey(resource);
    let callbackSet;
    const existingCallbackSet = updateCallbackSets.get(key);
    if (!existingCallbackSet) {
        callbackSet = {
            callbacks: new Set([
                callback
            ]),
            unsubscribe: subscribeToUpdates(sendMessage, resource)
        };
        updateCallbackSets.set(key, callbackSet);
    } else {
        existingCallbackSet.callbacks.add(callback);
        callbackSet = existingCallbackSet;
    }
    return ()=>{
        callbackSet.callbacks.delete(callback);
        if (callbackSet.callbacks.size === 0) {
            callbackSet.unsubscribe();
            updateCallbackSets.delete(key);
        }
    };
}
function triggerUpdate(msg) {
    const key = resourceKey(msg.resource);
    const callbackSet = updateCallbackSets.get(key);
    if (!callbackSet) {
        return;
    }
    for (const callback of callbackSet.callbacks){
        callback(msg);
    }
    if (msg.type === 'notFound') {
        // This indicates that the resource which we subscribed to either does not exist or
        // has been deleted. In either case, we should clear all update callbacks, so if a
        // new subscription is created for the same resource, it will send a new "subscribe"
        // message to the server.
        // No need to send an "unsubscribe" message to the server, it will have already
        // dropped the update stream before sending the "notFound" message.
        updateCallbackSets.delete(key);
    }
}
}),
"[project]/src/components/comman/ProjectCard.jsx [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ProjectCard",
    ()=>ProjectCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$router$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/router.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$hi2$2f$index$2e$mjs__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/hi2/index.mjs [client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
const ProjectCard = /*#__PURE__*/ _s((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["memo"])(_c = _s((param)=>{
    let { projectName, onHold, booked, total, available, slug, url, homePageData } = param;
    var _homePageData_button;
    _s();
    const stats = [
        {
            label: "Total",
            value: total,
            bgColor: "bg-[#FFF4F4]",
            textColor: "text-[#8C0000]",
            valueColor: "text-[#8C0000]"
        },
        {
            label: "Available",
            value: available,
            bgColor: "bg-[#FEF3C7]",
            textColor: "text-[#78350F]",
            valueColor: "text-[#78350F]"
        },
        {
            label: "On Hold",
            value: onHold,
            bgColor: "bg-[#DBEAFE]",
            textColor: "text-[#1E3A8A]",
            valueColor: "text-[#1E3A8A]"
        },
        {
            label: "Booked",
            value: booked,
            bgColor: "bg-[#DCFCE7]",
            textColor: "text-[#14532D]",
            valueColor: "text-[#14532D]"
        }
    ];
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$router$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useRouter"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "bg-white p-4 rounded-2xl shadow-lg border border-gray-200 w-full mx-auto",
        children: [
            url && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                src: url,
                width: 1200,
                height: 1200,
                quality: 95,
                priority: true,
                alt: "Image of ",
                className: "w-full xl:h-[240px] h-[200px] rounded-xl object-cover mb-4"
            }, void 0, false, {
                fileName: "[project]/src/components/comman/ProjectCard.jsx",
                lineNumber: 51,
                columnNumber: 11
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                className: "justify-center text-slate-800 text-xl font-bold leading-normal mb-3",
                children: projectName
            }, void 0, false, {
                fileName: "[project]/src/components/comman/ProjectCard.jsx",
                lineNumber: 61,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid grid-cols-2 gap-2 text-center text-sm md:text-base",
                children: stats === null || stats === void 0 ? void 0 : stats.map((stat, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "".concat(stat === null || stat === void 0 ? void 0 : stat.bgColor, " p-2 rounded-lg flex flex-row items-center justify-between px-3"),
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "block font-[500] ".concat(stat === null || stat === void 0 ? void 0 : stat.textColor),
                                children: stat === null || stat === void 0 ? void 0 : stat.label
                            }, void 0, false, {
                                fileName: "[project]/src/components/comman/ProjectCard.jsx",
                                lineNumber: 70,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "block font-bold xl:text-xl lg:text-md ".concat(stat === null || stat === void 0 ? void 0 : stat.valueColor),
                                children: stat === null || stat === void 0 ? void 0 : stat.value
                            }, void 0, false, {
                                fileName: "[project]/src/components/comman/ProjectCard.jsx",
                                lineNumber: 73,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, index, true, {
                        fileName: "[project]/src/components/comman/ProjectCard.jsx",
                        lineNumber: 66,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0)))
            }, void 0, false, {
                fileName: "[project]/src/components/comman/ProjectCard.jsx",
                lineNumber: 64,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                onClick: ()=>router.push("/properties/".concat(slug)),
                className: "w-full mt-6    text-white cursor-pointer font-[400] py-3 text-center flex   justify-center items-center gap-2 px-8 rounded-lg shadow-lg transition-all duration-300 ease-in-out transform hover:bg-[#055a87] bg-[#066FA9] hover:shadow-xl group",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: homePageData === null || homePageData === void 0 ? void 0 : (_homePageData_button = homePageData.button) === null || _homePageData_button === void 0 ? void 0 : _homePageData_button.text
                    }, void 0, false, {
                        fileName: "[project]/src/components/comman/ProjectCard.jsx",
                        lineNumber: 85,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "transition-transform duration-300 ease-in-out group-hover:translate-x-1",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$hi2$2f$index$2e$mjs__$5b$client$5d$__$28$ecmascript$29$__["HiOutlineArrowSmallRight"], {
                            className: "text-lg"
                        }, void 0, false, {
                            fileName: "[project]/src/components/comman/ProjectCard.jsx",
                            lineNumber: 87,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/src/components/comman/ProjectCard.jsx",
                        lineNumber: 86,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/comman/ProjectCard.jsx",
                lineNumber: 81,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/comman/ProjectCard.jsx",
        lineNumber: 49,
        columnNumber: 7
    }, ("TURBOPACK compile-time value", void 0));
}, "fN7XvhJ+p5oE6+Xlo0NJmXpxjC8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$router$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
})), "fN7XvhJ+p5oE6+Xlo0NJmXpxjC8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$router$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c1 = ProjectCard;
ProjectCard.displayName = "ProjectCard";
;
var _c, _c1;
__turbopack_context__.k.register(_c, "ProjectCard$memo");
__turbopack_context__.k.register(_c1, "ProjectCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/data.js [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// src/data/navbarData.js
__turbopack_context__.s([
    "applicantAutoFillData",
    ()=>applicantAutoFillData,
    "applicantData",
    ()=>applicantData,
    "applicantFields",
    ()=>applicantFields,
    "bookingData",
    ()=>bookingData,
    "bookingProjects",
    ()=>bookingProjects,
    "coApplicantFields",
    ()=>coApplicantFields,
    "homePageData",
    ()=>homePageData,
    "navbarData",
    ()=>navbarData
]);
const navbarData = {
    logo: {
        src: "/images/logo.png",
        link: "/",
        alt: "Navayan Logo"
    },
    disclaimerlinks: {
        text: "Disclaimer",
        href: "/disclaimer"
    },
    report_button: {
        text: "Report an Issue"
    }
};
const homePageData = {
    banner: {
        image: "/images/home1.png",
        alt: "A happy family jumping for joy in a park"
    },
    heading: "Available Projects",
    button: {
        text: "Add Booking",
        link: "/booking"
    },
    projects: [
        {
            projectName: "Navayan's Capital Park",
            total: 150,
            image: "/images/project_card.png",
            available: 35,
            onHold: 20,
            booked: 10
        },
        {
            projectName: "Navayan's West Gate",
            total: 150,
            image: "/images/project_card.png",
            available: 35,
            onHold: 20,
            booked: 10
        },
        {
            projectName: "Navayan's East Enclave",
            total: 200,
            image: "/images/project_card.png",
            available: 60,
            onHold: 25,
            booked: 15
        },
        {
            projectName: "Navayan's Capital Park",
            total: 150,
            image: "/images/project_card.png",
            available: 35,
            onHold: 20,
            booked: 10
        },
        {
            projectName: "Navayan's West Gate",
            total: 150,
            image: "/images/project_card.png",
            available: 35,
            onHold: 20,
            booked: 10
        },
        {
            projectName: "Navayan's East Enclave",
            total: 200,
            image: "/images/project_card.png",
            available: 60,
            onHold: 25,
            booked: 15
        }
    ]
};
const bookingData = {
    heading: "NEW BOOKING",
    inventoryHeading: "Inventory",
    searchPlaceholder: "Search unit",
    projects: [
        {
            projectName: "Navayan's Capital Park",
            project_subtitle: "Property Details",
            total: 150,
            image: "/images/project_card.png",
            available: 35,
            onHold: 20,
            booked: 10
        }
    ],
    table: {
        kycTable: false,
        BookingTableData: [
            {
                sn: 1,
                unitNo: "S1",
                plotSize: "1500 sq.ft.",
                plotFacing: "North",
                plc: "Garden",
                cost: "₹ 7,50,000",
                addCost: "₹ 50,000",
                status: "Available",
                booked: false
            },
            {
                sn: 1,
                unitNo: "S1",
                plotSize: "1500 sq.ft.",
                plotFacing: "North",
                plc: "Garden",
                cost: "₹ 7,50,000",
                addCost: "₹ 50,000",
                status: "Available",
                booked: false
            },
            {
                sn: 2,
                unitNo: "S2",
                plotSize: "1000 sq.ft.",
                plotFacing: "East",
                plc: "Corner",
                cost: "₹ 5,00,000",
                addCost: "₹ 50,000",
                status: "Booked",
                booked: true
            },
            {
                sn: 2,
                unitNo: "S2",
                plotSize: "1000 sq.ft.",
                plotFacing: "East",
                plc: "Corner",
                cost: "₹ 5,00,000",
                addCost: "₹ 50,000",
                status: "Booked",
                booked: true
            },
            {
                sn: 2,
                unitNo: "S2",
                plotSize: "1000 sq.ft.",
                plotFacing: "East",
                plc: "Corner",
                cost: "₹ 5,00,000",
                addCost: "₹ 50,000",
                status: "Booked",
                booked: true
            },
            {
                sn: 2,
                unitNo: "S2",
                plotSize: "1000 sq.ft.",
                plotFacing: "East",
                plc: "Corner",
                cost: "₹ 5,00,000",
                addCost: "₹ 50,000",
                status: "Booked",
                booked: true
            },
            {
                sn: 1,
                unitNo: "S1",
                plotSize: "1500 sq.ft.",
                plotFacing: "North",
                plc: "Garden",
                cost: "₹ 7,50,000",
                addCost: "₹ 50,000",
                status: "Available",
                booked: false
            },
            {
                sn: 2,
                unitNo: "S2",
                plotSize: "1000 sq.ft.",
                plotFacing: "East",
                plc: "Corner",
                cost: "₹ 5,00,000",
                addCost: "₹ 50,000",
                status: "Booked",
                booked: true
            },
            {
                sn: 2,
                unitNo: "S2",
                plotSize: "1000 sq.ft.",
                plotFacing: "East",
                plc: "Corner",
                cost: "₹ 5,00,000",
                addCost: "₹ 50,000",
                status: "Booked",
                booked: true
            },
            {
                sn: 1,
                unitNo: "S1",
                plotSize: "1500 sq.ft.",
                plotFacing: "North",
                plc: "Garden",
                cost: "₹ 7,50,000",
                addCost: "₹ 50,000",
                status: "Available",
                booked: false
            },
            {
                sn: 1,
                unitNo: "S1",
                plotSize: "1500 sq.ft.",
                plotFacing: "North",
                plc: "Garden",
                cost: "₹ 7,50,000",
                addCost: "₹ 50,000",
                status: "Available",
                booked: false
            }
        ]
    }
};
const bookingProjects = [
    {
        projectName: "Navayan's Capital Park",
        total: 150,
        available: 35,
        onHold: 20,
        booked: 10
    }
];
const applicantFields = [
    {
        name: "applicantName",
        placeholder: "Full Name of Applicant",
        type: "text"
    },
    {
        name: "applicantCof",
        placeholder: "C/o of",
        type: "text"
    },
    {
        name: "applicantPhone",
        placeholder: "Phone No. of Applicant",
        type: "tel"
    },
    {
        name: "applicantAdditionalPhone",
        placeholder: "Additional No. of Applicant",
        type: "tel"
    },
    {
        name: "applicantEmail",
        placeholder: "Email Id of Applicant",
        type: "email"
    },
    {
        name: "applicantAddress",
        placeholder: "Permanent Address of Applicant",
        type: "textarea"
    },
    {
        name: "applicantAadhar",
        placeholder: "Aadhar No. of Applicant",
        type: "text"
    },
    {
        name: "applicantPan",
        placeholder: "PAN No. of Applicant",
        type: "text"
    },
    {
        name: "applicantDob",
        placeholder: "Date of Birth",
        type: "date"
    },
    {
        name: "applicantProfession",
        placeholder: "Profession of Applicant",
        type: "text"
    }
];
const coApplicantFields = [
    {
        name: "coApplicantName",
        placeholder: "Full Name",
        type: "text"
    },
    {
        name: "coApplicantCof",
        placeholder: "C/o of",
        type: "text"
    },
    {
        name: "coApplicantPhone",
        placeholder: "Phone No.",
        type: "tel"
    },
    {
        name: "coApplicantAdditionalPhone",
        placeholder: "Additional No.",
        type: "tel"
    },
    {
        name: "coApplicantEmail",
        placeholder: "Email Id",
        type: "email"
    },
    {
        name: "coApplicantAddress",
        placeholder: "Permanent Address",
        type: "textarea"
    },
    {
        name: "coApplicantAadhar",
        placeholder: "Aadhar No.",
        type: "text"
    },
    {
        name: "coApplicantPan",
        placeholder: "PAN No.",
        type: "text"
    },
    {
        name: "coApplicantDob",
        placeholder: "Date of Birth",
        type: "date"
    },
    {
        name: "coApplicantProfession",
        placeholder: "Profession",
        type: "text"
    }
];
const applicantData = {
    "Full Name of Applicant": "Example Name",
    "C/o of": "Example Text",
    "Phone No. of Applicant": "7895289625",
    "Additional No. of Applicant": "2368896488",
    "Email Id of Applicant": "Example@gmail.com",
    "Permanent Address of Applicant": "123, this is the example address, city name, state, pincode et cetera",
    "Aadhar No. of Applicant": "85598568925745852",
    "PAN No. of Applicant": "HBUBB8857",
    DOB: "08/11/1990",
    "Profession of Applicant": "Example Text"
};
const applicantAutoFillData = {
    applicantAadhar: "496895208976",
    applicantAdditionalPhone: "8107545771",
    applicantAddress: "hello world",
    applicantCof: "abcd",
    applicantDob: "2025-09-18",
    applicantEmail: "abcd@gmail.com",
    applicantName: "sonu kumar saini",
    applicantPan: "56Ad67HJ",
    applicantPhone: "08107545771",
    applicantProfession: "acbd"
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/service/httpServices.js [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/axios/lib/axios.js [client] (ecmascript)");
;
const instance = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"].create({
    baseURL: "https://book.neotericproperties.in/wp-json/wp/v2",
    timeout: 60000,
    headers: {
        Accept: "application/json",
        "Content-Type": "application/json"
    }
});
const responseBody = (response)=>response.data;
const requests = {
    get: (url, config)=>instance.get(url, config).then(responseBody),
    post: (url, body, config)=>instance.post(url, body, config).then(responseBody),
    put: (url, body)=>instance.put(url, body).then(responseBody)
};
const __TURBOPACK__default__export__ = requests;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/service/allPages.js [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$httpServices$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/service/httpServices.js [client] (ecmascript)");
;
let propertiesCache = null;
const AllPages = {
    properties: async ()=>{
        if (propertiesCache) {
            return propertiesCache;
        }
        try {
            const timestamp = new Date().getTime(); // cache-busting if needed
            const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$httpServices$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"].get("/properties?acf_format=standard&t=".concat(timestamp));
            propertiesCache = response;
            return response;
        } catch (error) {
            var _error_response;
            console.error("Error fetching properties:", ((_error_response = error.response) === null || _error_response === void 0 ? void 0 : _error_response.data) || error.message);
            throw error;
        }
    },
    inventoryList: async (id)=>{
        try {
            const timestamp = new Date().getTime(); // cache-busting
            return await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$httpServices$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"].get("/sp_property_availability?property_id=".concat(id, "&t=").concat(timestamp));
        } catch (error) {
            var _error_response;
            console.error("Error fetching property detail:", ((_error_response = error.response) === null || _error_response === void 0 ? void 0 : _error_response.data) || error.message);
            throw error;
        }
    },
    holdFlat: async (id)=>{
        try {
            const res = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$httpServices$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"].post("/hold?property_id=41&plot_no=".concat(id));
            if (res.status) {
                console.log("Flat held successfully:", res.data);
            } else {
                console.error("Failed to hold flat:", res.data, "Code:", res.code);
            }
            return res; // ✅ always return data
        } catch (error) {
            var _error_response;
            console.error("Error fetching property detail:", ((_error_response = error.response) === null || _error_response === void 0 ? void 0 : _error_response.data) || error.message);
            throw error;
        }
    }
};
const __TURBOPACK__default__export__ = AllPages;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/pages/index.jsx [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$comman$2f$ProjectCard$2e$jsx__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/comman/ProjectCard.jsx [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/data.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$allPages$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/service/allPages.js [client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
const Home = (param)=>{
    let { projects: initialProjects = [] } = param;
    var _homePageData_banner, _homePageData_banner1;
    _s();
    const [projects, setProjects] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(initialProjects);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(!initialProjects.length);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Home.useEffect": ()=>{
            if (!initialProjects.length) {
                const availableProjectApiFun = {
                    "Home.useEffect.availableProjectApiFun": async ()=>{
                        try {
                            setLoading(true);
                            const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$allPages$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"].properties();
                            setProjects(response || []);
                        } catch (error) {
                            console.error("Error fetching projects:", error);
                            setProjects([]);
                        } finally{
                            setLoading(false);
                        }
                    }
                }["Home.useEffect.availableProjectApiFun"];
                availableProjectApiFun();
            }
        }
    }["Home.useEffect"], [
        initialProjects.length
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "max-w-screen-2xl mx-auto pb-16 px-6 md:px-8 lg:px-12 2xl:px-0",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative w-full overflow-hidden mt-20 rounded-xl",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2e$js__$5b$client$5d$__$28$ecmascript$29$__["homePageData"] === null || __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2e$js__$5b$client$5d$__$28$ecmascript$29$__["homePageData"] === void 0 ? void 0 : (_homePageData_banner = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2e$js__$5b$client$5d$__$28$ecmascript$29$__["homePageData"].banner) === null || _homePageData_banner === void 0 ? void 0 : _homePageData_banner.image,
                    alt: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2e$js__$5b$client$5d$__$28$ecmascript$29$__["homePageData"] === null || __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2e$js__$5b$client$5d$__$28$ecmascript$29$__["homePageData"] === void 0 ? void 0 : (_homePageData_banner1 = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2e$js__$5b$client$5d$__$28$ecmascript$29$__["homePageData"].banner) === null || _homePageData_banner1 === void 0 ? void 0 : _homePageData_banner1.alt,
                    width: 1200,
                    height: 400,
                    quality: 95,
                    priority: true,
                    className: "w-full lg:h-auto md:h-[350px] h-[200px] lg:object-contain object-cover"
                }, void 0, false, {
                    fileName: "[project]/src/pages/index.jsx",
                    lineNumber: 31,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/pages/index.jsx",
                lineNumber: 30,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-screen-2xl mx-auto md:pt-12",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "text-center justify-start text-neutral-900 md:text-[28px] text-2xl font-bold  leading-7 md:my-8 my-5",
                        children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2e$js__$5b$client$5d$__$28$ecmascript$29$__["homePageData"] === null || __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2e$js__$5b$client$5d$__$28$ecmascript$29$__["homePageData"] === void 0 ? void 0 : __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2e$js__$5b$client$5d$__$28$ecmascript$29$__["homePageData"].heading
                    }, void 0, false, {
                        fileName: "[project]/src/pages/index.jsx",
                        lineNumber: 42,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    loading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col justify-center items-center p-8",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "animate-spin rounded-full h-10 w-10 border-b-2 border-[#066FA9]",
                                style: {
                                    borderoBttomColor: "#066FA9"
                                }
                            }, void 0, false, {
                                fileName: "[project]/src/pages/index.jsx",
                                lineNumber: 47,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "mt-2 text-sm text-gray-600 animate-pulse",
                                children: "Loading projects..."
                            }, void 0, false, {
                                fileName: "[project]/src/pages/index.jsx",
                                lineNumber: 51,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/pages/index.jsx",
                        lineNumber: 46,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: " grid lg:grid-cols-3 md:grid-cols-2 grid-cols-1  items-center md:items-stretch justify-center xl:gap-8 gap-4",
                        children: projects === null || projects === void 0 ? void 0 : projects.map((project, index)=>{
                            var _project_acf_property_image, _project_acf, _project_title, _project_flats_available, _project_flats_available1, _project_flats_available2, _project_flats_available3;
                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$comman$2f$ProjectCard$2e$jsx__$5b$client$5d$__$28$ecmascript$29$__["ProjectCard"], {
                                url: project === null || project === void 0 ? void 0 : (_project_acf = project.acf) === null || _project_acf === void 0 ? void 0 : (_project_acf_property_image = _project_acf.property_image) === null || _project_acf_property_image === void 0 ? void 0 : _project_acf_property_image.url,
                                projectName: project === null || project === void 0 ? void 0 : (_project_title = project.title) === null || _project_title === void 0 ? void 0 : _project_title.rendered,
                                total: project === null || project === void 0 ? void 0 : (_project_flats_available = project.flats_available) === null || _project_flats_available === void 0 ? void 0 : _project_flats_available.total,
                                available: project === null || project === void 0 ? void 0 : (_project_flats_available1 = project.flats_available) === null || _project_flats_available1 === void 0 ? void 0 : _project_flats_available1.available,
                                onHold: project === null || project === void 0 ? void 0 : (_project_flats_available2 = project.flats_available) === null || _project_flats_available2 === void 0 ? void 0 : _project_flats_available2.hold,
                                booked: project === null || project === void 0 ? void 0 : (_project_flats_available3 = project.flats_available) === null || _project_flats_available3 === void 0 ? void 0 : _project_flats_available3.booked,
                                slug: project === null || project === void 0 ? void 0 : project.slug,
                                homePageData: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2e$js__$5b$client$5d$__$28$ecmascript$29$__["homePageData"]
                            }, index, false, {
                                fileName: "[project]/src/pages/index.jsx",
                                lineNumber: 58,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0));
                        })
                    }, void 0, false, {
                        fileName: "[project]/src/pages/index.jsx",
                        lineNumber: 56,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/pages/index.jsx",
                lineNumber: 41,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/pages/index.jsx",
        lineNumber: 29,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(Home, "evGn8OJQ1ubICFPGF69D4zUxYAw=");
_c = Home;
const __TURBOPACK__default__export__ = Home;
var _c;
__turbopack_context__.k.register(_c, "Home");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[next]/entry/page-loader.ts { PAGE => \"[project]/src/pages/index.jsx [client] (ecmascript)\" } [client] (ecmascript)", ((__turbopack_context__, module, exports) => {

const PAGE_PATH = "/";
(window.__NEXT_P = window.__NEXT_P || []).push([
    PAGE_PATH,
    ()=>{
        return __turbopack_context__.r("[project]/src/pages/index.jsx [client] (ecmascript)");
    }
]);
// @ts-expect-error module.hot exists
if (module.hot) {
    // @ts-expect-error module.hot exists
    module.hot.dispose(function() {
        window.__NEXT_P.push([
            PAGE_PATH
        ]);
    });
}
}),
"[hmr-entry]/hmr-entry.js { ENTRY => \"[project]/src/pages/index\" }", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.r("[next]/entry/page-loader.ts { PAGE => \"[project]/src/pages/index.jsx [client] (ecmascript)\" } [client] (ecmascript)");
}),
]);

//# sourceMappingURL=%5Broot-of-the-server%5D__191fa9b3._.js.map