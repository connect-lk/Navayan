(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_dist_compiled_next-devtools_index_5277ebc8.js",
  "static/chunks/node_modules_next_dist_compiled_166120c5._.js",
  "static/chunks/node_modules_next_dist_shared_lib_2c2ec201._.js",
  "static/chunks/node_modules_next_dist_client_d0aa886c._.js",
  "static/chunks/node_modules_next_dist_2e2215b7._.js",
  "static/chunks/node_modules_next_router_104fab1c.js",
  "static/chunks/node_modules_react-dom_4411d9bd._.js",
  "static/chunks/node_modules_lodash-es_84a20387._.js",
  "static/chunks/node_modules_react-icons_hi2_index_mjs_de626454._.js",
  "static/chunks/node_modules_react-icons_lib_7cd2a28b._.js",
  "static/chunks/node_modules_77f503fe._.js",
  "static/chunks/[root-of-the-server]__59c7b898._.js"
],
    source: "entry"
});
