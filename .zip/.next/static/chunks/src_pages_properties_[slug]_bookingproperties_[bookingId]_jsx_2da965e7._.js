(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__039960da._.js",
  "static/chunks/node_modules_next_dist_compiled_next-devtools_index_5277ebc8.js",
  "static/chunks/node_modules_next_dist_compiled_37759e4c._.js",
  "static/chunks/node_modules_next_dist_shared_lib_44774889._.js",
  "static/chunks/node_modules_next_dist_client_5677c419._.js",
  "static/chunks/node_modules_next_dist_2ff056ee._.js",
  "static/chunks/node_modules_next_41595870._.js",
  "static/chunks/node_modules_react-dom_4411d9bd._.js",
  "static/chunks/node_modules_react-icons_gr_index_mjs_bafbfed9._.js",
  "static/chunks/node_modules_react-icons_md_index_mjs_244d37ff._.js",
  "static/chunks/node_modules_react-icons_hi2_index_mjs_de626454._.js",
  "static/chunks/node_modules_react-icons_lib_7cd2a28b._.js",
  "static/chunks/node_modules_axios_lib_2c8bf6cb._.js",
  "static/chunks/node_modules_lodash-es_84a20387._.js",
  "static/chunks/node_modules_77f503fe._.js"
],
    source: "entry"
});
