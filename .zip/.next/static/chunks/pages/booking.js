__turbopack_load_page_chunks__("/booking", [
  "static/chunks/node_modules_next_dist_compiled_next-devtools_index_5277ebc8.js",
  "static/chunks/node_modules_next_dist_compiled_98c9bed4._.js",
  "static/chunks/node_modules_next_dist_shared_lib_16fa510a._.js",
  "static/chunks/node_modules_next_dist_client_bdba867a._.js",
  "static/chunks/node_modules_next_dist_2e2215b7._.js",
  "static/chunks/node_modules_next_a0b237e1._.js",
  "static/chunks/node_modules_react-dom_4411d9bd._.js",
  "static/chunks/node_modules_react-icons_io5_index_mjs_92991f0a._.js",
  "static/chunks/node_modules_react-icons_lib_7cd2a28b._.js",
  "static/chunks/node_modules_axios_lib_2c8bf6cb._.js",
  "static/chunks/node_modules_db346ff0._.js",
  "static/chunks/[root-of-the-server]__09e126cf._.js",
  "static/chunks/src_pages_booking_index_jsx_2da965e7._.js",
  "static/chunks/turbopack-src_pages_booking_index_jsx_41c02b68._.js"
])
