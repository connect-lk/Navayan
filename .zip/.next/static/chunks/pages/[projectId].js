__turbopack_load_page_chunks__("/[projectId]", [
  "static/chunks/node_modules_next_dist_compiled_next-devtools_index_5277ebc8.js",
  "static/chunks/node_modules_next_dist_compiled_166120c5._.js",
  "static/chunks/node_modules_next_dist_shared_lib_2c2ec201._.js",
  "static/chunks/node_modules_next_dist_client_d0aa886c._.js",
  "static/chunks/node_modules_next_dist_2e2215b7._.js",
  "static/chunks/node_modules_react-dom_4411d9bd._.js",
  "static/chunks/node_modules_db346ff0._.js",
  "static/chunks/[root-of-the-server]__fd792066._.js",
  "static/chunks/src_pages_[projectId]_index_jsx_2da965e7._.js",
  "static/chunks/turbopack-src_pages_[projectId]_index_jsx_f58a8686._.js"
])
