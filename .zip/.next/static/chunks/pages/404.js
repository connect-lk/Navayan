__turbopack_load_page_chunks__("/404", [
  "static/chunks/node_modules_next_dist_compiled_next-devtools_index_5277ebc8.js",
  "static/chunks/node_modules_next_dist_compiled_166120c5._.js",
  "static/chunks/node_modules_next_dist_shared_lib_f041b118._.js",
  "static/chunks/node_modules_next_dist_client_3ede7da4._.js",
  "static/chunks/node_modules_next_dist_2e2215b7._.js",
  "static/chunks/node_modules_next_link_207af988.js",
  "static/chunks/node_modules_react-dom_4411d9bd._.js",
  "static/chunks/node_modules_db346ff0._.js",
  "static/chunks/[root-of-the-server]__85ba9d59._.js",
  "static/chunks/src_pages_404_2da965e7._.js",
  "static/chunks/turbopack-src_pages_404_e282f25c._.js"
])
