__turbopack_load_page_chunks__("/", [
  "static/chunks/node_modules_next_dist_compiled_next-devtools_index_5277ebc8.js",
  "static/chunks/node_modules_next_dist_compiled_98c9bed4._.js",
  "static/chunks/node_modules_next_dist_shared_lib_16fa510a._.js",
  "static/chunks/node_modules_next_dist_client_bdba867a._.js",
  "static/chunks/node_modules_next_dist_2e2215b7._.js",
  "static/chunks/node_modules_next_a0b237e1._.js",
  "static/chunks/node_modules_react-dom_4411d9bd._.js",
  "static/chunks/node_modules_react-icons_hi2_index_mjs_de626454._.js",
  "static/chunks/node_modules_react-icons_lib_7cd2a28b._.js",
  "static/chunks/node_modules_axios_lib_2c8bf6cb._.js",
  "static/chunks/node_modules_db346ff0._.js",
  "static/chunks/[root-of-the-server]__191fa9b3._.js",
  "static/chunks/src_pages_index_2da965e7._.js",
  "static/chunks/turbopack-src_pages_index_04ef114d._.js"
])
