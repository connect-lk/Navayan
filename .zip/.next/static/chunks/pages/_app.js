__turbopack_load_page_chunks__("/_app", [
  "static/chunks/node_modules_next_dist_compiled_next-devtools_index_5277ebc8.js",
  "static/chunks/node_modules_next_dist_compiled_aa9d047d._.js",
  "static/chunks/node_modules_next_dist_shared_lib_854924ee._.js",
  "static/chunks/node_modules_next_dist_client_45e9549c._.js",
  "static/chunks/node_modules_next_dist_2e2215b7._.js",
  "static/chunks/node_modules_next_36e64248._.js",
  "static/chunks/node_modules_react-dom_4411d9bd._.js",
  "static/chunks/node_modules_35bce592._.js",
  "static/chunks/[root-of-the-server]__45260626._.js",
  "static/chunks/src_styles_globals_5bb75e7e.css",
  "static/chunks/src_pages__app_2da965e7._.js",
  "static/chunks/turbopack-src_pages__app_e53b77f6._.js"
])
