(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[turbopack]/browser/dev/hmr-client/hmr-client.ts [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/// <reference path="../../../shared/runtime-types.d.ts" />
/// <reference path="../../runtime/base/dev-globals.d.ts" />
/// <reference path="../../runtime/base/dev-protocol.d.ts" />
/// <reference path="../../runtime/base/dev-extensions.ts" />
__turbopack_context__.s([
    "connect",
    ()=>connect,
    "setHooks",
    ()=>setHooks,
    "subscribeToUpdate",
    ()=>subscribeToUpdate
]);
function connect(param) {
    let { addMessageListener, sendMessage, onUpdateError = console.error } = param;
    addMessageListener((msg)=>{
        switch(msg.type){
            case 'turbopack-connected':
                handleSocketConnected(sendMessage);
                break;
            default:
                try {
                    if (Array.isArray(msg.data)) {
                        for(let i = 0; i < msg.data.length; i++){
                            handleSocketMessage(msg.data[i]);
                        }
                    } else {
                        handleSocketMessage(msg.data);
                    }
                    applyAggregatedUpdates();
                } catch (e) {
                    console.warn('[Fast Refresh] performing full reload\n\n' + "Fast Refresh will perform a full reload when you edit a file that's imported by modules outside of the React rendering tree.\n" + 'You might have a file which exports a React component but also exports a value that is imported by a non-React component file.\n' + 'Consider migrating the non-React component export to a separate file and importing it into both files.\n\n' + 'It is also possible the parent component of the component you edited is a class component, which disables Fast Refresh.\n' + 'Fast Refresh requires at least one parent function component in your React tree.');
                    onUpdateError(e);
                    location.reload();
                }
                break;
        }
    });
    const queued = globalThis.TURBOPACK_CHUNK_UPDATE_LISTENERS;
    if (queued != null && !Array.isArray(queued)) {
        throw new Error('A separate HMR handler was already registered');
    }
    globalThis.TURBOPACK_CHUNK_UPDATE_LISTENERS = {
        push: (param)=>{
            let [chunkPath, callback] = param;
            subscribeToChunkUpdate(chunkPath, sendMessage, callback);
        }
    };
    if (Array.isArray(queued)) {
        for (const [chunkPath, callback] of queued){
            subscribeToChunkUpdate(chunkPath, sendMessage, callback);
        }
    }
}
const updateCallbackSets = new Map();
function sendJSON(sendMessage, message) {
    sendMessage(JSON.stringify(message));
}
function resourceKey(resource) {
    return JSON.stringify({
        path: resource.path,
        headers: resource.headers || null
    });
}
function subscribeToUpdates(sendMessage, resource) {
    sendJSON(sendMessage, {
        type: 'turbopack-subscribe',
        ...resource
    });
    return ()=>{
        sendJSON(sendMessage, {
            type: 'turbopack-unsubscribe',
            ...resource
        });
    };
}
function handleSocketConnected(sendMessage) {
    for (const key of updateCallbackSets.keys()){
        subscribeToUpdates(sendMessage, JSON.parse(key));
    }
}
// we aggregate all pending updates until the issues are resolved
const chunkListsWithPendingUpdates = new Map();
function aggregateUpdates(msg) {
    const key = resourceKey(msg.resource);
    let aggregated = chunkListsWithPendingUpdates.get(key);
    if (aggregated) {
        aggregated.instruction = mergeChunkListUpdates(aggregated.instruction, msg.instruction);
    } else {
        chunkListsWithPendingUpdates.set(key, msg);
    }
}
function applyAggregatedUpdates() {
    if (chunkListsWithPendingUpdates.size === 0) return;
    hooks.beforeRefresh();
    for (const msg of chunkListsWithPendingUpdates.values()){
        triggerUpdate(msg);
    }
    chunkListsWithPendingUpdates.clear();
    finalizeUpdate();
}
function mergeChunkListUpdates(updateA, updateB) {
    let chunks;
    if (updateA.chunks != null) {
        if (updateB.chunks == null) {
            chunks = updateA.chunks;
        } else {
            chunks = mergeChunkListChunks(updateA.chunks, updateB.chunks);
        }
    } else if (updateB.chunks != null) {
        chunks = updateB.chunks;
    }
    let merged;
    if (updateA.merged != null) {
        if (updateB.merged == null) {
            merged = updateA.merged;
        } else {
            // Since `merged` is an array of updates, we need to merge them all into
            // one, consistent update.
            // Since there can only be `EcmascriptMergeUpdates` in the array, there is
            // no need to key on the `type` field.
            let update = updateA.merged[0];
            for(let i = 1; i < updateA.merged.length; i++){
                update = mergeChunkListEcmascriptMergedUpdates(update, updateA.merged[i]);
            }
            for(let i = 0; i < updateB.merged.length; i++){
                update = mergeChunkListEcmascriptMergedUpdates(update, updateB.merged[i]);
            }
            merged = [
                update
            ];
        }
    } else if (updateB.merged != null) {
        merged = updateB.merged;
    }
    return {
        type: 'ChunkListUpdate',
        chunks,
        merged
    };
}
function mergeChunkListChunks(chunksA, chunksB) {
    const chunks = {};
    for (const [chunkPath, chunkUpdateA] of Object.entries(chunksA)){
        const chunkUpdateB = chunksB[chunkPath];
        if (chunkUpdateB != null) {
            const mergedUpdate = mergeChunkUpdates(chunkUpdateA, chunkUpdateB);
            if (mergedUpdate != null) {
                chunks[chunkPath] = mergedUpdate;
            }
        } else {
            chunks[chunkPath] = chunkUpdateA;
        }
    }
    for (const [chunkPath, chunkUpdateB] of Object.entries(chunksB)){
        if (chunks[chunkPath] == null) {
            chunks[chunkPath] = chunkUpdateB;
        }
    }
    return chunks;
}
function mergeChunkUpdates(updateA, updateB) {
    if (updateA.type === 'added' && updateB.type === 'deleted' || updateA.type === 'deleted' && updateB.type === 'added') {
        return undefined;
    }
    if (updateA.type === 'partial') {
        invariant(updateA.instruction, 'Partial updates are unsupported');
    }
    if (updateB.type === 'partial') {
        invariant(updateB.instruction, 'Partial updates are unsupported');
    }
    return undefined;
}
function mergeChunkListEcmascriptMergedUpdates(mergedA, mergedB) {
    const entries = mergeEcmascriptChunkEntries(mergedA.entries, mergedB.entries);
    const chunks = mergeEcmascriptChunksUpdates(mergedA.chunks, mergedB.chunks);
    return {
        type: 'EcmascriptMergedUpdate',
        entries,
        chunks
    };
}
function mergeEcmascriptChunkEntries(entriesA, entriesB) {
    return {
        ...entriesA,
        ...entriesB
    };
}
function mergeEcmascriptChunksUpdates(chunksA, chunksB) {
    if (chunksA == null) {
        return chunksB;
    }
    if (chunksB == null) {
        return chunksA;
    }
    const chunks = {};
    for (const [chunkPath, chunkUpdateA] of Object.entries(chunksA)){
        const chunkUpdateB = chunksB[chunkPath];
        if (chunkUpdateB != null) {
            const mergedUpdate = mergeEcmascriptChunkUpdates(chunkUpdateA, chunkUpdateB);
            if (mergedUpdate != null) {
                chunks[chunkPath] = mergedUpdate;
            }
        } else {
            chunks[chunkPath] = chunkUpdateA;
        }
    }
    for (const [chunkPath, chunkUpdateB] of Object.entries(chunksB)){
        if (chunks[chunkPath] == null) {
            chunks[chunkPath] = chunkUpdateB;
        }
    }
    if (Object.keys(chunks).length === 0) {
        return undefined;
    }
    return chunks;
}
function mergeEcmascriptChunkUpdates(updateA, updateB) {
    if (updateA.type === 'added' && updateB.type === 'deleted') {
        // These two completely cancel each other out.
        return undefined;
    }
    if (updateA.type === 'deleted' && updateB.type === 'added') {
        const added = [];
        const deleted = [];
        var _updateA_modules;
        const deletedModules = new Set((_updateA_modules = updateA.modules) !== null && _updateA_modules !== void 0 ? _updateA_modules : []);
        var _updateB_modules;
        const addedModules = new Set((_updateB_modules = updateB.modules) !== null && _updateB_modules !== void 0 ? _updateB_modules : []);
        for (const moduleId of addedModules){
            if (!deletedModules.has(moduleId)) {
                added.push(moduleId);
            }
        }
        for (const moduleId of deletedModules){
            if (!addedModules.has(moduleId)) {
                deleted.push(moduleId);
            }
        }
        if (added.length === 0 && deleted.length === 0) {
            return undefined;
        }
        return {
            type: 'partial',
            added,
            deleted
        };
    }
    if (updateA.type === 'partial' && updateB.type === 'partial') {
        var _updateA_added, _updateB_added;
        const added = new Set([
            ...(_updateA_added = updateA.added) !== null && _updateA_added !== void 0 ? _updateA_added : [],
            ...(_updateB_added = updateB.added) !== null && _updateB_added !== void 0 ? _updateB_added : []
        ]);
        var _updateA_deleted, _updateB_deleted;
        const deleted = new Set([
            ...(_updateA_deleted = updateA.deleted) !== null && _updateA_deleted !== void 0 ? _updateA_deleted : [],
            ...(_updateB_deleted = updateB.deleted) !== null && _updateB_deleted !== void 0 ? _updateB_deleted : []
        ]);
        if (updateB.added != null) {
            for (const moduleId of updateB.added){
                deleted.delete(moduleId);
            }
        }
        if (updateB.deleted != null) {
            for (const moduleId of updateB.deleted){
                added.delete(moduleId);
            }
        }
        return {
            type: 'partial',
            added: [
                ...added
            ],
            deleted: [
                ...deleted
            ]
        };
    }
    if (updateA.type === 'added' && updateB.type === 'partial') {
        var _updateA_modules1, _updateB_added1;
        const modules = new Set([
            ...(_updateA_modules1 = updateA.modules) !== null && _updateA_modules1 !== void 0 ? _updateA_modules1 : [],
            ...(_updateB_added1 = updateB.added) !== null && _updateB_added1 !== void 0 ? _updateB_added1 : []
        ]);
        var _updateB_deleted1;
        for (const moduleId of (_updateB_deleted1 = updateB.deleted) !== null && _updateB_deleted1 !== void 0 ? _updateB_deleted1 : []){
            modules.delete(moduleId);
        }
        return {
            type: 'added',
            modules: [
                ...modules
            ]
        };
    }
    if (updateA.type === 'partial' && updateB.type === 'deleted') {
        var _updateB_modules1;
        // We could eagerly return `updateB` here, but this would potentially be
        // incorrect if `updateA` has added modules.
        const modules = new Set((_updateB_modules1 = updateB.modules) !== null && _updateB_modules1 !== void 0 ? _updateB_modules1 : []);
        if (updateA.added != null) {
            for (const moduleId of updateA.added){
                modules.delete(moduleId);
            }
        }
        return {
            type: 'deleted',
            modules: [
                ...modules
            ]
        };
    }
    // Any other update combination is invalid.
    return undefined;
}
function invariant(_, message) {
    throw new Error("Invariant: ".concat(message));
}
const CRITICAL = [
    'bug',
    'error',
    'fatal'
];
function compareByList(list, a, b) {
    const aI = list.indexOf(a) + 1 || list.length;
    const bI = list.indexOf(b) + 1 || list.length;
    return aI - bI;
}
const chunksWithIssues = new Map();
function emitIssues() {
    const issues = [];
    const deduplicationSet = new Set();
    for (const [_, chunkIssues] of chunksWithIssues){
        for (const chunkIssue of chunkIssues){
            if (deduplicationSet.has(chunkIssue.formatted)) continue;
            issues.push(chunkIssue);
            deduplicationSet.add(chunkIssue.formatted);
        }
    }
    sortIssues(issues);
    hooks.issues(issues);
}
function handleIssues(msg) {
    const key = resourceKey(msg.resource);
    let hasCriticalIssues = false;
    for (const issue of msg.issues){
        if (CRITICAL.includes(issue.severity)) {
            hasCriticalIssues = true;
        }
    }
    if (msg.issues.length > 0) {
        chunksWithIssues.set(key, msg.issues);
    } else if (chunksWithIssues.has(key)) {
        chunksWithIssues.delete(key);
    }
    emitIssues();
    return hasCriticalIssues;
}
const SEVERITY_ORDER = [
    'bug',
    'fatal',
    'error',
    'warning',
    'info',
    'log'
];
const CATEGORY_ORDER = [
    'parse',
    'resolve',
    'code generation',
    'rendering',
    'typescript',
    'other'
];
function sortIssues(issues) {
    issues.sort((a, b)=>{
        const first = compareByList(SEVERITY_ORDER, a.severity, b.severity);
        if (first !== 0) return first;
        return compareByList(CATEGORY_ORDER, a.category, b.category);
    });
}
const hooks = {
    beforeRefresh: ()=>{},
    refresh: ()=>{},
    buildOk: ()=>{},
    issues: (_issues)=>{}
};
function setHooks(newHooks) {
    Object.assign(hooks, newHooks);
}
function handleSocketMessage(msg) {
    sortIssues(msg.issues);
    handleIssues(msg);
    switch(msg.type){
        case 'issues':
            break;
        case 'partial':
            // aggregate updates
            aggregateUpdates(msg);
            break;
        default:
            // run single update
            const runHooks = chunkListsWithPendingUpdates.size === 0;
            if (runHooks) hooks.beforeRefresh();
            triggerUpdate(msg);
            if (runHooks) finalizeUpdate();
            break;
    }
}
function finalizeUpdate() {
    hooks.refresh();
    hooks.buildOk();
    // This is used by the Next.js integration test suite to notify it when HMR
    // updates have been completed.
    // TODO: Only run this in test environments (gate by `process.env.__NEXT_TEST_MODE`)
    if (globalThis.__NEXT_HMR_CB) {
        globalThis.__NEXT_HMR_CB();
        globalThis.__NEXT_HMR_CB = null;
    }
}
function subscribeToChunkUpdate(chunkListPath, sendMessage, callback) {
    return subscribeToUpdate({
        path: chunkListPath
    }, sendMessage, callback);
}
function subscribeToUpdate(resource, sendMessage, callback) {
    const key = resourceKey(resource);
    let callbackSet;
    const existingCallbackSet = updateCallbackSets.get(key);
    if (!existingCallbackSet) {
        callbackSet = {
            callbacks: new Set([
                callback
            ]),
            unsubscribe: subscribeToUpdates(sendMessage, resource)
        };
        updateCallbackSets.set(key, callbackSet);
    } else {
        existingCallbackSet.callbacks.add(callback);
        callbackSet = existingCallbackSet;
    }
    return ()=>{
        callbackSet.callbacks.delete(callback);
        if (callbackSet.callbacks.size === 0) {
            callbackSet.unsubscribe();
            updateCallbackSets.delete(key);
        }
    };
}
function triggerUpdate(msg) {
    const key = resourceKey(msg.resource);
    const callbackSet = updateCallbackSets.get(key);
    if (!callbackSet) {
        return;
    }
    for (const callback of callbackSet.callbacks){
        callback(msg);
    }
    if (msg.type === 'notFound') {
        // This indicates that the resource which we subscribed to either does not exist or
        // has been deleted. In either case, we should clear all update callbacks, so if a
        // new subscription is created for the same resource, it will send a new "subscribe"
        // message to the server.
        // No need to send an "unsubscribe" message to the server, it will have already
        // dropped the update stream before sending the "notFound" message.
        updateCallbackSets.delete(key);
    }
}
}),
"[project]/src/components/comman/NewBookingCard.jsx [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "NewBookingCard",
    ()=>NewBookingCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [client] (ecmascript)");
;
;
;
const NewBookingCard = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["memo"])(_c = (param)=>{
    let { projectName, onHold, booked, total, available, url, project_subtitle } = param;
    const stats = [
        {
            label: "Total",
            value: total,
            bgColor: "bg-[#FFF4F4]",
            textColor: "text-[#8C0000]",
            valueColor: "text-[#8C0000]"
        },
        {
            label: "Available",
            value: available,
            bgColor: "bg-[#FEF3C7]",
            textColor: "text-[#78350F]",
            valueColor: "text-[#78350F]"
        },
        {
            label: "On Hold",
            value: onHold,
            bgColor: "bg-[#DBEAFE]",
            textColor: "text-[#1E3A8A]",
            valueColor: "text-[#1E3A8A]"
        },
        {
            label: "Booked",
            value: booked,
            bgColor: "bg-[#DCFCE7]",
            textColor: "text-[#14532D]",
            valueColor: "text-[#14532D]"
        }
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "bg-white p-4 rounded-2xl flex flex-col md:flex-row items-stretch gap-4 md:gap-8   w-full max-w-screen-2xl mx-auto",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex-shrink-0 w-full md:w-1/3 border-none",
                children: url && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                    src: url,
                    width: 1200,
                    height: 1200,
                    quality: 95,
                    alt: projectName,
                    priority: true,
                    className: "w-full h-[230px] rounded-xl object-cover"
                }, void 0, false, {
                    fileName: "[project]/src/components/comman/NewBookingCard.jsx",
                    lineNumber: 49,
                    columnNumber: 13
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/components/comman/NewBookingCard.jsx",
                lineNumber: 47,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col justify-between w-full md:w-2/3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-md font-medium text-gray-500 mb-1",
                                children: project_subtitle
                            }, void 0, false, {
                                fileName: "[project]/src/components/comman/NewBookingCard.jsx",
                                lineNumber: 63,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                className: "text-2xl font-bold text-[#1F2937] mb-4",
                                children: projectName
                            }, void 0, false, {
                                fileName: "[project]/src/components/comman/NewBookingCard.jsx",
                                lineNumber: 66,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/comman/NewBookingCard.jsx",
                        lineNumber: 62,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-2 gap-2 text-center text-sm w-full md:text-base",
                        children: stats === null || stats === void 0 ? void 0 : stats.map((stat, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "".concat(stat === null || stat === void 0 ? void 0 : stat.bgColor, " xl:p-3  p-2 rounded-lg flex flex-row border border-[#E3E3E3] items-center justify-between px-3"),
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "block font-medium ".concat(stat === null || stat === void 0 ? void 0 : stat.textColor),
                                        children: stat === null || stat === void 0 ? void 0 : stat.label
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/comman/NewBookingCard.jsx",
                                        lineNumber: 78,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "block font-bold text-xl ".concat(stat === null || stat === void 0 ? void 0 : stat.valueColor),
                                        children: stat === null || stat === void 0 ? void 0 : stat.value
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/comman/NewBookingCard.jsx",
                                        lineNumber: 81,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, index, true, {
                                fileName: "[project]/src/components/comman/NewBookingCard.jsx",
                                lineNumber: 74,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0)))
                    }, void 0, false, {
                        fileName: "[project]/src/components/comman/NewBookingCard.jsx",
                        lineNumber: 72,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/comman/NewBookingCard.jsx",
                lineNumber: 61,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/comman/NewBookingCard.jsx",
        lineNumber: 46,
        columnNumber: 7
    }, ("TURBOPACK compile-time value", void 0));
});
_c1 = NewBookingCard;
NewBookingCard.displayName = "NewBookingCard";
;
var _c, _c1;
__turbopack_context__.k.register(_c, "NewBookingCard$memo");
__turbopack_context__.k.register(_c1, "NewBookingCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/service/httpServices.js [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/axios/lib/axios.js [client] (ecmascript)");
;
const instance = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"].create({
    baseURL: "https://book.neotericproperties.in/wp-json/wp/v2",
    timeout: 60000,
    headers: {
        Accept: "application/json",
        "Content-Type": "application/json"
    }
});
const responseBody = (response)=>response.data;
const requests = {
    get: (url, config)=>instance.get(url, config).then(responseBody),
    post: (url, body, config)=>instance.post(url, body, config).then(responseBody),
    put: (url, body)=>instance.put(url, body).then(responseBody)
};
const __TURBOPACK__default__export__ = requests;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/service/allPages.js [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$httpServices$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/service/httpServices.js [client] (ecmascript)");
;
let propertiesCache = null;
const AllPages = {
    properties: async ()=>{
        if (propertiesCache) {
            return propertiesCache;
        }
        try {
            const timestamp = new Date().getTime(); // cache-busting if needed
            const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$httpServices$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"].get("/properties?acf_format=standard&t=".concat(timestamp));
            propertiesCache = response;
            return response;
        } catch (error) {
            var _error_response;
            console.error("Error fetching properties:", ((_error_response = error.response) === null || _error_response === void 0 ? void 0 : _error_response.data) || error.message);
            throw error;
        }
    },
    inventoryList: async (id)=>{
        try {
            const timestamp = new Date().getTime(); // cache-busting
            return await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$httpServices$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"].get("/sp_property_availability?property_id=".concat(id, "&t=").concat(timestamp));
        } catch (error) {
            var _error_response;
            console.error("Error fetching property detail:", ((_error_response = error.response) === null || _error_response === void 0 ? void 0 : _error_response.data) || error.message);
            throw error;
        }
    },
    holdFlat: async (id)=>{
        try {
            const res = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$httpServices$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"].post("/hold?property_id=41&plot_no=".concat(id));
            if (res.status) {
                console.log("Flat held successfully:", res.data);
            } else {
                console.error("Failed to hold flat:", res.data, "Code:", res.code);
            }
            return res; // ✅ always return data
        } catch (error) {
            var _error_response;
            console.error("Error fetching property detail:", ((_error_response = error.response) === null || _error_response === void 0 ? void 0 : _error_response.data) || error.message);
            throw error;
        }
    }
};
const __TURBOPACK__default__export__ = AllPages;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/comman/InventoryTable.jsx [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$router$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/router.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gr$2f$index$2e$mjs__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/gr/index.mjs [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$md$2f$index$2e$mjs__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/md/index.mjs [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$allPages$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/service/allPages.js [client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
const InventoryTable = /*#__PURE__*/ _s((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["memo"])(_c = _s((param)=>{
    let { kycTable, tableData, slug, loading, InventoryListApiFun } = param;
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$router$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const [currentPage, setCurrentPage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(1);
    const [now, setNow] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(new Date()); // track current time
    const rowsPerPage = 20;
    // ✅ Update current time every second
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "InventoryTable.useEffect": ()=>{
            const interval = setInterval({
                "InventoryTable.useEffect.interval": ()=>setNow(new Date())
            }["InventoryTable.useEffect.interval"], 1000);
            return ({
                "InventoryTable.useEffect": ()=>clearInterval(interval)
            })["InventoryTable.useEffect"];
        }
    }["InventoryTable.useEffect"], []);
    const indexOfLastRow = currentPage * rowsPerPage;
    const indexOfFirstRow = indexOfLastRow - rowsPerPage;
    const currentRows = tableData === null || tableData === void 0 ? void 0 : tableData.slice(indexOfFirstRow, indexOfLastRow);
    const totalPages = Math.ceil((tableData === null || tableData === void 0 ? void 0 : tableData.length) / rowsPerPage);
    // ⏳ Format mm:ss
    const formatTime = (seconds)=>{
        const m = Math.floor(seconds / 60).toString().padStart(2, "0");
        const s = (seconds % 60).toString().padStart(2, "0");
        return "".concat(m, ":").concat(s);
    };
    const getRemainingTime = (expiresAt)=>{
        if (!expiresAt) return 0;
        const expiry = new Date(expiresAt.replace(" ", "T")).getTime();
        const now = new Date().getTime();
        const diff = Math.round((expiry - now) / 1000); // round instead of floor
        return diff > 0 ? diff : 0;
    };
    // 📌 Book Now
    const handleBookNow = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "InventoryTable.useCallback[handleBookNow]": async (plotNo)=>{
            try {
                const res = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$allPages$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"].holdFlat(plotNo);
                console.log("API Response:", res);
                InventoryListApiFun();
                router.push("/properties/".concat(slug, "/bookingproperties/").concat(plotNo));
            } catch (error) {
                console.error("Booking failed:", error.message);
            }
        }
    }["InventoryTable.useCallback[handleBookNow]"], [
        router,
        slug
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "bg-white rounded-xl min-h-auto shadow-sm",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "rounded-xl overflow-hidden bg-gray-100",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "overflow-x-auto relative",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                        className: "w-full table-auto border-collapse whitespace-nowrap",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                    className: "bg-[#f9fafb] border-b border-gray-200 text-[#6B7280] text-sm xl:text-[15px]",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            className: "font-semibold xl:px-3 px-3 py-5 text-center bg-[#f9fafb] sticky left-0 z-10",
                                            children: "PLOT NO."
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                            lineNumber: 67,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            className: "font-semibold xl:px-3 px-3 py-5 text-center",
                                            children: "PLOT SIZE"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                            lineNumber: 70,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            className: "font-semibold xl:px-3 px-3 py-5 text-center",
                                            children: "FACING"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                            lineNumber: 73,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            className: "font-semibold xl:px-3 px-3 py-5 text-center",
                                            children: "PLC SIDE"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                            lineNumber: 76,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            className: "font-semibold xl:px-3 px-3 py-5 text-center",
                                            children: "PLC %"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                            lineNumber: 79,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            className: "font-semibold xl:px-3 px-3 py-5 text-center",
                                            children: "NORTH"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                            lineNumber: 82,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            className: "font-semibold xl:px-3 px-3 py-5 text-center",
                                            children: "SOUTH"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                            lineNumber: 85,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            className: "font-semibold xl:px-3 px-3 py-5 text-center",
                                            children: "EAST"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                            lineNumber: 88,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            className: "font-semibold xl:px-3 px-3 py-5 text-center",
                                            children: "WEST"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                            lineNumber: 91,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            className: "font-semibold xl:px-3 px-3 py-5 text-center",
                                            children: "WITH PLC"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                            lineNumber: 94,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            className: "font-semibold xl:px-3 px-3 py-5 text-center",
                                            children: "ADDITIONAL"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                            lineNumber: 97,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            className: "font-semibold xl:px-3 px-3 py-5 text-center",
                                            children: "TOTAL"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                            lineNumber: 100,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            className: "font-semibold xl:px-3 px-3 py-5 text-center",
                                            children: "STATUS"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                            lineNumber: 103,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        kycTable !== "kycTable" && kycTable !== "ReviewTable" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            className: "font-semibold xl:px-3 px-3 py-5 text-center bg-[#f9fafb] sticky right-0 z-10",
                                            children: "BOOK"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                            lineNumber: 107,
                                            columnNumber: 21
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                    lineNumber: 66,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                lineNumber: 65,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                                className: "divide-y divide-gray-200",
                                children: loading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                        colSpan: "14",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex justify-center items-center w-full h-16",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "animate-spin rounded-full h-8 w-8 border-b-2 border-[#066FA9]"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                                    lineNumber: 119,
                                                    columnNumber: 25
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "ml-3 text-sm",
                                                    children: "Loading property..."
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                                    lineNumber: 120,
                                                    columnNumber: 25
                                                }, ("TURBOPACK compile-time value", void 0))
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                            lineNumber: 118,
                                            columnNumber: 23
                                        }, ("TURBOPACK compile-time value", void 0))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                        lineNumber: 117,
                                        columnNumber: 21
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                    lineNumber: 116,
                                    columnNumber: 19
                                }, ("TURBOPACK compile-time value", void 0)) : (currentRows === null || currentRows === void 0 ? void 0 : currentRows.length) > 0 ? currentRows.map((row, index)=>{
                                    var _row_status, _row_status1;
                                    const remainingTime = getRemainingTime(row === null || row === void 0 ? void 0 : row.hold_expires_at, row === null || row === void 0 ? void 0 : row.created_at);
                                    const isHoldActive = remainingTime > 0;
                                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                        className: "bg-white hover:bg-gray-50 transition-colors duration-200 text-sm text-[#6B7280] md:text-base",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                className: "xl:p-3 p-3 text-center bg-white sticky left-0 z-10",
                                                children: row === null || row === void 0 ? void 0 : row.plotNo
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                                lineNumber: 139,
                                                columnNumber: 25
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                className: "xl:p-3 p-3 text-center",
                                                children: row === null || row === void 0 ? void 0 : row.plotSize
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                                lineNumber: 142,
                                                columnNumber: 25
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                className: "xl:p-3 p-3 text-center",
                                                children: row === null || row === void 0 ? void 0 : row.plotFacing
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                                lineNumber: 145,
                                                columnNumber: 25
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                className: "xl:p-3 p-3 text-center",
                                                children: row === null || row === void 0 ? void 0 : row.plcSide
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                                lineNumber: 148,
                                                columnNumber: 25
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                className: "xl:p-3 p-3 text-center",
                                                children: row === null || row === void 0 ? void 0 : row.plcPercentage
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                                lineNumber: 151,
                                                columnNumber: 25
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                className: "xl:p-3 p-3 text-center",
                                                children: row === null || row === void 0 ? void 0 : row.north
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                                lineNumber: 154,
                                                columnNumber: 25
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                className: "xl:p-3 p-3 text-center",
                                                children: row === null || row === void 0 ? void 0 : row.south
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                                lineNumber: 155,
                                                columnNumber: 25
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                className: "xl:p-3 p-3 text-center",
                                                children: row === null || row === void 0 ? void 0 : row.east
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                                lineNumber: 156,
                                                columnNumber: 25
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                className: "xl:p-3 p-3 text-center",
                                                children: row === null || row === void 0 ? void 0 : row.west
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                                lineNumber: 157,
                                                columnNumber: 25
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                className: "xl:p-3 p-3 text-center",
                                                children: row === null || row === void 0 ? void 0 : row.withPlc
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                                lineNumber: 158,
                                                columnNumber: 25
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                className: "xl:p-3 p-3 text-center",
                                                children: row === null || row === void 0 ? void 0 : row.additional
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                                lineNumber: 161,
                                                columnNumber: 25
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                className: "xl:p-3 p-3 text-center",
                                                children: row === null || row === void 0 ? void 0 : row.total
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                                lineNumber: 164,
                                                columnNumber: 25
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                className: "xl:p-3 p-3 text-center",
                                                children: isHoldActive ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "px-2.5 py-1.5 rounded-sm text-sm font-semibold bg-blue-50 text-[#066FA9]",
                                                    children: [
                                                        "Hold (",
                                                        formatTime(remainingTime),
                                                        ")"
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                                    lineNumber: 168,
                                                    columnNumber: 29
                                                }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "px-2.5 py-1.5 rounded-sm text-sm font-semibold ".concat(((_row_status = row.status) === null || _row_status === void 0 ? void 0 : _row_status.toLowerCase()) === "available" ? "bg-green-50 text-green-800" : ((_row_status1 = row.status) === null || _row_status1 === void 0 ? void 0 : _row_status1.toLowerCase()) === "booked" ? "bg-red-50 text-red-800" : "bg-gray-100 text-gray-600"),
                                                    children: row.status
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                                    lineNumber: 172,
                                                    columnNumber: 29
                                                }, ("TURBOPACK compile-time value", void 0))
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                                lineNumber: 166,
                                                columnNumber: 25
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            kycTable !== "kycTable" && kycTable !== "ReviewTable" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                className: "p-4 text-center bg-white sticky right-0 z-10",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    onClick: ()=>handleBookNow(row === null || row === void 0 ? void 0 : row.plotNo),
                                                    className: "font-semibold px-4 py-2 text-[14px] w-fit rounded-lg shadow-lg transition-all duration-300 ease-in-out transform hover:shadow-xl ".concat((row === null || row === void 0 ? void 0 : row.booked) || isHoldActive ? "bg-[#D1D5DB] text-[#4B5563] cursor-not-allowed" : "hover:bg-[#055a87] bg-[#066FA9] text-white cursor-pointer"),
                                                    disabled: (row === null || row === void 0 ? void 0 : row.booked) || isHoldActive,
                                                    children: (row === null || row === void 0 ? void 0 : row.booked) ? "Booked" : isHoldActive ? "Hold" : "Book Now"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                                    lineNumber: 189,
                                                    columnNumber: 31
                                                }, ("TURBOPACK compile-time value", void 0))
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                                lineNumber: 188,
                                                columnNumber: 29
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, index, true, {
                                        fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                        lineNumber: 135,
                                        columnNumber: 23
                                    }, ("TURBOPACK compile-time value", void 0));
                                }) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                        colSpan: "14",
                                        className: "text-center py-6 text-gray-500",
                                        children: "No data found"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                        lineNumber: 211,
                                        columnNumber: 21
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                    lineNumber: 210,
                                    columnNumber: 19
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                lineNumber: 114,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/comman/InventoryTable.jsx",
                        lineNumber: 64,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/components/comman/InventoryTable.jsx",
                    lineNumber: 63,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0)),
                (tableData === null || tableData === void 0 ? void 0 : tableData.length) > rowsPerPage && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex justify-between px-6 items-center gap-3 p-4 border-t border-gray-200",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: ()=>setCurrentPage((prev)=>Math.max(prev - 1, 1)),
                            disabled: currentPage === 1,
                            className: "flex items-center gap-1 text-sm text-gray-600 disabled:opacity-50 cursor-pointer",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$md$2f$index$2e$mjs__$5b$client$5d$__$28$ecmascript$29$__["MdArrowBackIosNew"], {
                                    className: "text-xs"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                    lineNumber: 228,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "sm:block hidden",
                                    children: "PREVIOUS"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                    lineNumber: 229,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/comman/InventoryTable.jsx",
                            lineNumber: 223,
                            columnNumber: 15
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-1",
                            children: (()=>{
                                const pages = [];
                                const isMobile = "object" !== "undefined" && window.innerWidth < 640;
                                const maxPageButtons = isMobile ? 3 : 7;
                                let startPage = Math.max(currentPage - 3, 1);
                                let endPage = Math.min(startPage + maxPageButtons - 1, totalPages);
                                if (endPage - startPage < maxPageButtons - 1) {
                                    startPage = Math.max(endPage - maxPageButtons + 1, 1);
                                }
                                if (startPage > 1) {
                                    pages.push(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>setCurrentPage(1),
                                        className: "sm:w-10 w-8 sm:h-10 h-8 flex items-center justify-center rounded-full text-sm font-medium transition ".concat(currentPage === 1 ? "bg-[#066FA9] text-white" : "transition-all shadow-sm hover:shadow-lg border border-slate-200 text-slate-600 hover:text-white hover:bg-[#066FA9]"),
                                        children: "1"
                                    }, 1, false, {
                                        fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                        lineNumber: 251,
                                        columnNumber: 23
                                    }, ("TURBOPACK compile-time value", void 0)));
                                    if (startPage > 2) pages.push(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "px-2",
                                        children: "..."
                                    }, "start-ellipsis", false, {
                                        fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                        lineNumber: 265,
                                        columnNumber: 25
                                    }, ("TURBOPACK compile-time value", void 0)));
                                }
                                for(let i = startPage; i <= endPage; i++){
                                    pages.push(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>setCurrentPage(i),
                                        className: "sm:w-10 w-8 sm:h-10 h-8 flex items-center justify-center rounded-full text-sm font-medium transition ".concat(currentPage === i ? "bg-[#066FA9] text-white" : "transition-all shadow-sm hover:shadow-lg border border-slate-200 text-slate-600 hover:text-white hover:bg-[#066FA9]"),
                                        children: i
                                    }, i, false, {
                                        fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                        lineNumber: 273,
                                        columnNumber: 23
                                    }, ("TURBOPACK compile-time value", void 0)));
                                }
                                if (endPage < totalPages) {
                                    if (endPage < totalPages - 1) pages.push(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "px-2",
                                        children: "..."
                                    }, "end-ellipsis", false, {
                                        fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                        lineNumber: 290,
                                        columnNumber: 25
                                    }, ("TURBOPACK compile-time value", void 0)));
                                    pages.push(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>setCurrentPage(totalPages),
                                        className: "sm:w-10 w-8 sm:h-10 h-8 flex items-center justify-center rounded-full text-sm font-medium transition sm:block hidden ".concat(currentPage === totalPages ? "bg-[#066FA9] text-white" : "transition-all shadow-sm hover:shadow-lg border border-slate-200 text-slate-600 hover:text-white hover:bg-[#066FA9]"),
                                        children: totalPages
                                    }, totalPages, false, {
                                        fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                        lineNumber: 295,
                                        columnNumber: 23
                                    }, ("TURBOPACK compile-time value", void 0)));
                                }
                                return pages;
                            })()
                        }, void 0, false, {
                            fileName: "[project]/src/components/comman/InventoryTable.jsx",
                            lineNumber: 232,
                            columnNumber: 15
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: ()=>setCurrentPage((prev)=>Math.min(prev + 1, totalPages)),
                            disabled: currentPage === totalPages,
                            className: "flex items-center gap-1 text-sm text-gray-600 disabled:opacity-50 cursor-pointer",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "sm:block hidden",
                                    children: "NEXT"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                    lineNumber: 320,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$gr$2f$index$2e$mjs__$5b$client$5d$__$28$ecmascript$29$__["GrNext"], {
                                    className: "text-xs"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                    lineNumber: 321,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/comman/InventoryTable.jsx",
                            lineNumber: 313,
                            columnNumber: 15
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/comman/InventoryTable.jsx",
                    lineNumber: 222,
                    columnNumber: 13
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/comman/InventoryTable.jsx",
            lineNumber: 62,
            columnNumber: 9
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/components/comman/InventoryTable.jsx",
        lineNumber: 61,
        columnNumber: 7
    }, ("TURBOPACK compile-time value", void 0));
}, "4wQDXdAUpbkG+1gc0pCAefWG8DA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$router$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
})), "4wQDXdAUpbkG+1gc0pCAefWG8DA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$router$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c1 = InventoryTable;
InventoryTable.displayName = "InventoryTable";
const __TURBOPACK__default__export__ = InventoryTable;
var _c, _c1;
__turbopack_context__.k.register(_c, "InventoryTable$memo");
__turbopack_context__.k.register(_c1, "InventoryTable");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/data.js [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// src/data/navbarData.js
__turbopack_context__.s([
    "applicantAutoFillData",
    ()=>applicantAutoFillData,
    "applicantData",
    ()=>applicantData,
    "applicantFields",
    ()=>applicantFields,
    "bookingData",
    ()=>bookingData,
    "bookingProjects",
    ()=>bookingProjects,
    "coApplicantFields",
    ()=>coApplicantFields,
    "homePageData",
    ()=>homePageData,
    "navbarData",
    ()=>navbarData
]);
const navbarData = {
    logo: {
        src: "/images/logo.png",
        link: "/",
        alt: "Navayan Logo"
    },
    disclaimerlinks: {
        text: "Disclaimer",
        href: "/disclaimer"
    },
    report_button: {
        text: "Report an Issue"
    }
};
const homePageData = {
    banner: {
        image: "/images/home1.png",
        alt: "A happy family jumping for joy in a park"
    },
    heading: "Available Projects",
    button: {
        text: "Add Booking",
        link: "/booking"
    },
    projects: [
        {
            projectName: "Navayan's Capital Park",
            total: 150,
            image: "/images/project_card.png",
            available: 35,
            onHold: 20,
            booked: 10
        },
        {
            projectName: "Navayan's West Gate",
            total: 150,
            image: "/images/project_card.png",
            available: 35,
            onHold: 20,
            booked: 10
        },
        {
            projectName: "Navayan's East Enclave",
            total: 200,
            image: "/images/project_card.png",
            available: 60,
            onHold: 25,
            booked: 15
        },
        {
            projectName: "Navayan's Capital Park",
            total: 150,
            image: "/images/project_card.png",
            available: 35,
            onHold: 20,
            booked: 10
        },
        {
            projectName: "Navayan's West Gate",
            total: 150,
            image: "/images/project_card.png",
            available: 35,
            onHold: 20,
            booked: 10
        },
        {
            projectName: "Navayan's East Enclave",
            total: 200,
            image: "/images/project_card.png",
            available: 60,
            onHold: 25,
            booked: 15
        }
    ]
};
const bookingData = {
    heading: "NEW BOOKING",
    inventoryHeading: "Inventory",
    searchPlaceholder: "Search unit",
    projects: [
        {
            projectName: "Navayan's Capital Park",
            project_subtitle: "Property Details",
            total: 150,
            image: "/images/project_card.png",
            available: 35,
            onHold: 20,
            booked: 10
        }
    ],
    table: {
        kycTable: false,
        BookingTableData: [
            {
                sn: 1,
                unitNo: "S1",
                plotSize: "1500 sq.ft.",
                plotFacing: "North",
                plc: "Garden",
                cost: "₹ 7,50,000",
                addCost: "₹ 50,000",
                status: "Available",
                booked: false
            },
            {
                sn: 1,
                unitNo: "S1",
                plotSize: "1500 sq.ft.",
                plotFacing: "North",
                plc: "Garden",
                cost: "₹ 7,50,000",
                addCost: "₹ 50,000",
                status: "Available",
                booked: false
            },
            {
                sn: 2,
                unitNo: "S2",
                plotSize: "1000 sq.ft.",
                plotFacing: "East",
                plc: "Corner",
                cost: "₹ 5,00,000",
                addCost: "₹ 50,000",
                status: "Booked",
                booked: true
            },
            {
                sn: 2,
                unitNo: "S2",
                plotSize: "1000 sq.ft.",
                plotFacing: "East",
                plc: "Corner",
                cost: "₹ 5,00,000",
                addCost: "₹ 50,000",
                status: "Booked",
                booked: true
            },
            {
                sn: 2,
                unitNo: "S2",
                plotSize: "1000 sq.ft.",
                plotFacing: "East",
                plc: "Corner",
                cost: "₹ 5,00,000",
                addCost: "₹ 50,000",
                status: "Booked",
                booked: true
            },
            {
                sn: 2,
                unitNo: "S2",
                plotSize: "1000 sq.ft.",
                plotFacing: "East",
                plc: "Corner",
                cost: "₹ 5,00,000",
                addCost: "₹ 50,000",
                status: "Booked",
                booked: true
            },
            {
                sn: 1,
                unitNo: "S1",
                plotSize: "1500 sq.ft.",
                plotFacing: "North",
                plc: "Garden",
                cost: "₹ 7,50,000",
                addCost: "₹ 50,000",
                status: "Available",
                booked: false
            },
            {
                sn: 2,
                unitNo: "S2",
                plotSize: "1000 sq.ft.",
                plotFacing: "East",
                plc: "Corner",
                cost: "₹ 5,00,000",
                addCost: "₹ 50,000",
                status: "Booked",
                booked: true
            },
            {
                sn: 2,
                unitNo: "S2",
                plotSize: "1000 sq.ft.",
                plotFacing: "East",
                plc: "Corner",
                cost: "₹ 5,00,000",
                addCost: "₹ 50,000",
                status: "Booked",
                booked: true
            },
            {
                sn: 1,
                unitNo: "S1",
                plotSize: "1500 sq.ft.",
                plotFacing: "North",
                plc: "Garden",
                cost: "₹ 7,50,000",
                addCost: "₹ 50,000",
                status: "Available",
                booked: false
            },
            {
                sn: 1,
                unitNo: "S1",
                plotSize: "1500 sq.ft.",
                plotFacing: "North",
                plc: "Garden",
                cost: "₹ 7,50,000",
                addCost: "₹ 50,000",
                status: "Available",
                booked: false
            }
        ]
    }
};
const bookingProjects = [
    {
        projectName: "Navayan's Capital Park",
        total: 150,
        available: 35,
        onHold: 20,
        booked: 10
    }
];
const applicantFields = [
    {
        name: "applicantName",
        placeholder: "Full Name of Applicant",
        type: "text"
    },
    {
        name: "applicantCof",
        placeholder: "C/o of",
        type: "text"
    },
    {
        name: "applicantPhone",
        placeholder: "Phone No. of Applicant",
        type: "tel"
    },
    {
        name: "applicantAdditionalPhone",
        placeholder: "Additional No. of Applicant",
        type: "tel"
    },
    {
        name: "applicantEmail",
        placeholder: "Email Id of Applicant",
        type: "email"
    },
    {
        name: "applicantAddress",
        placeholder: "Permanent Address of Applicant",
        type: "textarea"
    },
    {
        name: "applicantAadhar",
        placeholder: "Aadhar No. of Applicant",
        type: "text"
    },
    {
        name: "applicantPan",
        placeholder: "PAN No. of Applicant",
        type: "text"
    },
    {
        name: "applicantDob",
        placeholder: "Date of Birth",
        type: "date"
    },
    {
        name: "applicantProfession",
        placeholder: "Profession of Applicant",
        type: "text"
    }
];
const coApplicantFields = [
    {
        name: "coApplicantName",
        placeholder: "Full Name",
        type: "text"
    },
    {
        name: "coApplicantCof",
        placeholder: "C/o of",
        type: "text"
    },
    {
        name: "coApplicantPhone",
        placeholder: "Phone No.",
        type: "tel"
    },
    {
        name: "coApplicantAdditionalPhone",
        placeholder: "Additional No.",
        type: "tel"
    },
    {
        name: "coApplicantEmail",
        placeholder: "Email Id",
        type: "email"
    },
    {
        name: "coApplicantAddress",
        placeholder: "Permanent Address",
        type: "textarea"
    },
    {
        name: "coApplicantAadhar",
        placeholder: "Aadhar No.",
        type: "text"
    },
    {
        name: "coApplicantPan",
        placeholder: "PAN No.",
        type: "text"
    },
    {
        name: "coApplicantDob",
        placeholder: "Date of Birth",
        type: "date"
    },
    {
        name: "coApplicantProfession",
        placeholder: "Profession",
        type: "text"
    }
];
const applicantData = {
    "Full Name of Applicant": "Example Name",
    "C/o of": "Example Text",
    "Phone No. of Applicant": "7895289625",
    "Additional No. of Applicant": "2368896488",
    "Email Id of Applicant": "Example@gmail.com",
    "Permanent Address of Applicant": "123, this is the example address, city name, state, pincode et cetera",
    "Aadhar No. of Applicant": "85598568925745852",
    "PAN No. of Applicant": "HBUBB8857",
    DOB: "08/11/1990",
    "Profession of Applicant": "Example Text"
};
const applicantAutoFillData = {
    applicantAadhar: "496895208976",
    applicantAdditionalPhone: "8107545771",
    applicantAddress: "hello world",
    applicantCof: "abcd",
    applicantDob: "2025-09-18",
    applicantEmail: "abcd@gmail.com",
    applicantName: "sonu kumar saini",
    applicantPan: "56Ad67HJ",
    applicantPhone: "08107545771",
    applicantProfession: "acbd"
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/pages/properties/[slug]/index.jsx [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$io5$2f$index$2e$mjs__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/io5/index.mjs [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$comman$2f$NewBookingCard$2e$jsx__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/comman/NewBookingCard.jsx [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$comman$2f$InventoryTable$2e$jsx__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/comman/InventoryTable.jsx [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/data.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$allPages$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/service/allPages.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$router$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/router.js [client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
const index = ()=>{
    var _project_acf_property_image, _project_acf, _project_title, _project_flats_available, _project_flats_available1, _project_flats_available2, _project_flats_available3;
    _s();
    const [inventoryList, setInventoryList] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [searchText, setSearchText] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(""); // <-- Add search state
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$router$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const { slug } = router.query; // get slug from URL
    const [project, setProject] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const fetchProject = async ()=>{
        if (!slug) return;
        try {
            setLoading(true);
            const allProjects = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$allPages$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"].properties();
            const matchedProject = allProjects.find((p)=>p.slug === slug);
            setProject(matchedProject);
        } catch (error) {
            console.error("Error fetching project:", error);
            setProject([]);
            setLoading(false);
        } finally{
            setLoading(false);
        }
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "index.useEffect": ()=>{
            fetchProject();
        }
    }["index.useEffect"], [
        slug
    ]);
    const InventoryListApiFun = async ()=>{
        try {
            const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$allPages$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"].inventoryList(41);
            setInventoryList(response === null || response === void 0 ? void 0 : response.data);
            console.log("response", response === null || response === void 0 ? void 0 : response.data[0]);
        } catch (error) {
            console.error("Error fetching inventory list:", error);
        }
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "index.useEffect": ()=>{
            InventoryListApiFun();
        }
    }["index.useEffect"], []);
    const holdFlatFun = async (id)=>{
        try {
            await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$allPages$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"].holdFlat(id);
        } catch (error) {
            console.error("Error holding flat:", error.message);
        }
    };
    const tableData = (inventoryList === null || inventoryList === void 0 ? void 0 : inventoryList.map((item, index)=>{
        var _item_status;
        return {
            id: item === null || item === void 0 ? void 0 : item.id,
            sn: index + 1,
            plotNo: item === null || item === void 0 ? void 0 : item.plot_no,
            plotSize: "".concat(item === null || item === void 0 ? void 0 : item.plot_size, " sq.ft"),
            plotFacing: item === null || item === void 0 ? void 0 : item.facing,
            plcSide: item === null || item === void 0 ? void 0 : item.plc_side,
            plcPercentage: "".concat(item === null || item === void 0 ? void 0 : item.plc_percentage, "%"),
            north: item === null || item === void 0 ? void 0 : item.north,
            south: item === null || item === void 0 ? void 0 : item.south,
            east: item === null || item === void 0 ? void 0 : item.east,
            west: item === null || item === void 0 ? void 0 : item.west,
            withPlc: "₹".concat(item === null || item === void 0 ? void 0 : item.with_plc),
            additional: "₹".concat(item === null || item === void 0 ? void 0 : item.additional),
            total: "₹".concat(item === null || item === void 0 ? void 0 : item.total),
            status: item === null || item === void 0 ? void 0 : item.status,
            hold_expires_at: item === null || item === void 0 ? void 0 : item.hold_expires_at,
            created_at: item === null || item === void 0 ? void 0 : item.created_at,
            booked: (item === null || item === void 0 ? void 0 : (_item_status = item.status) === null || _item_status === void 0 ? void 0 : _item_status.toLowerCase()) !== "available"
        };
    })) || [];
    // Filter based on searchText
    const filteredData = tableData === null || tableData === void 0 ? void 0 : tableData.filter((item)=>{
        var _item_plotNo;
        return item === null || item === void 0 ? void 0 : (_item_plotNo = item.plotNo) === null || _item_plotNo === void 0 ? void 0 : _item_plotNo.toLowerCase().includes(searchText === null || searchText === void 0 ? void 0 : searchText.toLowerCase());
    });
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "max-w-screen-2xl mx-auto pb-16 px-6 min-h-screen   md:px-8 lg:px-12 2xl:px-0 ",
        children: loading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex justify-center items-center gap-6 h-64",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "animate-spin rounded-full h-8 w-8 border-b-2 border-[#066FA9]"
                }, void 0, false, {
                    fileName: "[project]/src/pages/properties/[slug]/index.jsx",
                    lineNumber: 92,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "ml-3 text-lg",
                    children: "Loading property..."
                }, void 0, false, {
                    fileName: "[project]/src/pages/properties/[slug]/index.jsx",
                    lineNumber: 93,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/pages/properties/[slug]/index.jsx",
            lineNumber: 91,
            columnNumber: 9
        }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "max-w-screen-2xl mx-auto pt-12",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: "text-center justify-start text-neutral-900 md:text-3xl text-2xl font-bold leading-7 md:my-8 my-6",
                            children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2e$js__$5b$client$5d$__$28$ecmascript$29$__["bookingData"] === null || __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2e$js__$5b$client$5d$__$28$ecmascript$29$__["bookingData"] === void 0 ? void 0 : __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2e$js__$5b$client$5d$__$28$ecmascript$29$__["bookingData"].heading
                        }, void 0, false, {
                            fileName: "[project]/src/pages/properties/[slug]/index.jsx",
                            lineNumber: 98,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "grid grid-cols-1 w-full items-center md:items-stretch justify-center xl:gap-8 gap-4",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$comman$2f$NewBookingCard$2e$jsx__$5b$client$5d$__$28$ecmascript$29$__["NewBookingCard"], {
                                project_subtitle: "Property Details",
                                url: project === null || project === void 0 ? void 0 : (_project_acf = project.acf) === null || _project_acf === void 0 ? void 0 : (_project_acf_property_image = _project_acf.property_image) === null || _project_acf_property_image === void 0 ? void 0 : _project_acf_property_image.url,
                                projectName: project === null || project === void 0 ? void 0 : (_project_title = project.title) === null || _project_title === void 0 ? void 0 : _project_title.rendered,
                                total: project === null || project === void 0 ? void 0 : (_project_flats_available = project.flats_available) === null || _project_flats_available === void 0 ? void 0 : _project_flats_available.total,
                                available: project === null || project === void 0 ? void 0 : (_project_flats_available1 = project.flats_available) === null || _project_flats_available1 === void 0 ? void 0 : _project_flats_available1.available,
                                onHold: project === null || project === void 0 ? void 0 : (_project_flats_available2 = project.flats_available) === null || _project_flats_available2 === void 0 ? void 0 : _project_flats_available2.hold,
                                booked: project === null || project === void 0 ? void 0 : (_project_flats_available3 = project.flats_available) === null || _project_flats_available3 === void 0 ? void 0 : _project_flats_available3.booked,
                                slug: project === null || project === void 0 ? void 0 : project.slug
                            }, void 0, false, {
                                fileName: "[project]/src/pages/properties/[slug]/index.jsx",
                                lineNumber: 102,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/src/pages/properties/[slug]/index.jsx",
                            lineNumber: 101,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/pages/properties/[slug]/index.jsx",
                    lineNumber: 97,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "w-full py-4",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col sm:flex-row items-center justify-between ",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                className: "text-2xl md:text-[28px] font-bold text-gray-800 mb-4 sm:mb-0 md:block hidden",
                                children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2e$js__$5b$client$5d$__$28$ecmascript$29$__["bookingData"] === null || __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2e$js__$5b$client$5d$__$28$ecmascript$29$__["bookingData"] === void 0 ? void 0 : __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2e$js__$5b$client$5d$__$28$ecmascript$29$__["bookingData"].inventoryHeading
                            }, void 0, false, {
                                fileName: "[project]/src/pages/properties/[slug]/index.jsx",
                                lineNumber: 116,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-full sm:w-80",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "relative flex items-center bg-white rounded-xl  ",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                            type: "text",
                                            placeholder: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2e$js__$5b$client$5d$__$28$ecmascript$29$__["bookingData"] === null || __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2e$js__$5b$client$5d$__$28$ecmascript$29$__["bookingData"] === void 0 ? void 0 : __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2e$js__$5b$client$5d$__$28$ecmascript$29$__["bookingData"].searchPlaceholder,
                                            className: "w-full py-3.5 pl-4 pr-10 text-sm text-gray-700 font-[600] placeholder-gray-500 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#066fa9]",
                                            value: searchText,
                                            onChange: (e)=>setSearchText(e.target.value)
                                        }, void 0, false, {
                                            fileName: "[project]/src/pages/properties/[slug]/index.jsx",
                                            lineNumber: 122,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$io5$2f$index$2e$mjs__$5b$client$5d$__$28$ecmascript$29$__["IoSearchOutline"], {
                                            className: "absolute right-3 w-5 h-5 font-[900] text-gray-500"
                                        }, void 0, false, {
                                            fileName: "[project]/src/pages/properties/[slug]/index.jsx",
                                            lineNumber: 129,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/pages/properties/[slug]/index.jsx",
                                    lineNumber: 121,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/src/pages/properties/[slug]/index.jsx",
                                lineNumber: 120,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/pages/properties/[slug]/index.jsx",
                        lineNumber: 115,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/pages/properties/[slug]/index.jsx",
                    lineNumber: 114,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$comman$2f$InventoryTable$2e$jsx__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                    tableData: filteredData,
                    holdFlatFun: holdFlatFun,
                    InventoryListApiFun: InventoryListApiFun,
                    slug: slug
                }, void 0, false, {
                    fileName: "[project]/src/pages/properties/[slug]/index.jsx",
                    lineNumber: 134,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true)
    }, void 0, false, {
        fileName: "[project]/src/pages/properties/[slug]/index.jsx",
        lineNumber: 89,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(index, "xgCRwf/S0fvuoypJGg7+ljAMc+Y=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$router$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
const __TURBOPACK__default__export__ = index;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[next]/entry/page-loader.ts { PAGE => \"[project]/src/pages/properties/[slug]/index.jsx [client] (ecmascript)\" } [client] (ecmascript)", ((__turbopack_context__, module, exports) => {

const PAGE_PATH = "/properties/[slug]";
(window.__NEXT_P = window.__NEXT_P || []).push([
    PAGE_PATH,
    ()=>{
        return __turbopack_context__.r("[project]/src/pages/properties/[slug]/index.jsx [client] (ecmascript)");
    }
]);
// @ts-expect-error module.hot exists
if (module.hot) {
    // @ts-expect-error module.hot exists
    module.hot.dispose(function() {
        window.__NEXT_P.push([
            PAGE_PATH
        ]);
    });
}
}),
"[hmr-entry]/hmr-entry.js { ENTRY => \"[project]/src/pages/properties/[slug]/index.jsx\" }", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.r("[next]/entry/page-loader.ts { PAGE => \"[project]/src/pages/properties/[slug]/index.jsx [client] (ecmascript)\" } [client] (ecmascript)");
}),
]);

//# sourceMappingURL=%5Broot-of-the-server%5D__244fe083._.js.map