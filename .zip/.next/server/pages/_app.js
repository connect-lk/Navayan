var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_app.js")
R.c("server/chunks/ssr/node_modules_8dc82c88._.js")
R.c("server/chunks/ssr/[root-of-the-server]__06a3dce6._.js")
R.m("[project]/src/pages/_app.js [ssr] (ecmascript)")
module.exports=R.m("[project]/src/pages/_app.js [ssr] (ecmascript)").exports
