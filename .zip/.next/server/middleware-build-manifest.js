globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/node_modules_next_dist_compiled_next-devtools_index_5277ebc8.js",
      "static/chunks/node_modules_next_dist_compiled_aa9d047d._.js",
      "static/chunks/node_modules_next_dist_shared_lib_854924ee._.js",
      "static/chunks/node_modules_next_dist_client_45e9549c._.js",
      "static/chunks/node_modules_next_dist_2e2215b7._.js",
      "static/chunks/node_modules_next_36e64248._.js",
      "static/chunks/node_modules_react-dom_4411d9bd._.js",
      "static/chunks/node_modules_35bce592._.js",
      "static/chunks/[root-of-the-server]__45260626._.js",
      "static/chunks/src_styles_globals_5bb75e7e.css",
      "static/chunks/src_pages__app_2da965e7._.js",
      "static/chunks/turbopack-src_pages__app_e53b77f6._.js"
    ],
    "/properties/[slug]": [
      "static/chunks/node_modules_next_dist_compiled_next-devtools_index_5277ebc8.js",
      "static/chunks/node_modules_next_dist_compiled_98c9bed4._.js",
      "static/chunks/node_modules_next_dist_shared_lib_16fa510a._.js",
      "static/chunks/node_modules_next_dist_client_bdba867a._.js",
      "static/chunks/node_modules_next_dist_2e2215b7._.js",
      "static/chunks/node_modules_next_a0b237e1._.js",
      "static/chunks/node_modules_react-dom_4411d9bd._.js",
      "static/chunks/node_modules_react-icons_io5_index_mjs_92991f0a._.js",
      "static/chunks/node_modules_react-icons_gr_index_mjs_bafbfed9._.js",
      "static/chunks/node_modules_react-icons_md_index_mjs_244d37ff._.js",
      "static/chunks/node_modules_react-icons_lib_7cd2a28b._.js",
      "static/chunks/node_modules_axios_lib_2c8bf6cb._.js",
      "static/chunks/node_modules_db346ff0._.js",
      "static/chunks/[root-of-the-server]__244fe083._.js",
      "static/chunks/src_pages_properties_[slug]_index_jsx_2da965e7._.js",
      "static/chunks/turbopack-src_pages_properties_[slug]_index_jsx_b900ee30._.js"
    ],
    "/properties/[slug]/bookingproperties/[bookingId]": [
      "static/chunks/[root-of-the-server]__039960da._.js",
      "static/chunks/node_modules_next_dist_compiled_next-devtools_index_5277ebc8.js",
      "static/chunks/node_modules_next_dist_compiled_37759e4c._.js",
      "static/chunks/node_modules_next_dist_shared_lib_44774889._.js",
      "static/chunks/node_modules_next_dist_client_5677c419._.js",
      "static/chunks/node_modules_next_dist_2ff056ee._.js",
      "static/chunks/node_modules_next_41595870._.js",
      "static/chunks/node_modules_react-dom_4411d9bd._.js",
      "static/chunks/node_modules_react-icons_gr_index_mjs_bafbfed9._.js",
      "static/chunks/node_modules_react-icons_md_index_mjs_244d37ff._.js",
      "static/chunks/node_modules_react-icons_hi2_index_mjs_de626454._.js",
      "static/chunks/node_modules_react-icons_lib_7cd2a28b._.js",
      "static/chunks/node_modules_axios_lib_2c8bf6cb._.js",
      "static/chunks/node_modules_lodash-es_84a20387._.js",
      "static/chunks/node_modules_77f503fe._.js",
      "static/chunks/src_pages_properties_[slug]_bookingproperties_[bookingId]_jsx_2da965e7._.js",
      "static/chunks/turbopack-src_pages_properties_[slug]_bookingproperties_[bookingId]_jsx_8493d0ae._.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [],
  "lowPriorityFiles": [],
  "rootMainFiles": [],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];