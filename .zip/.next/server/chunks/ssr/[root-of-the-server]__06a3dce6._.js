module.exports = [
"[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("react/jsx-dev-runtime", () => require("react/jsx-dev-runtime"));

module.exports = mod;
}),
"[externals]/react/jsx-runtime [external] (react/jsx-runtime, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("react/jsx-runtime", () => require("react/jsx-runtime"));

module.exports = mod;
}),
"[externals]/react [external] (react, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("react", () => require("react"));

module.exports = mod;
}),
"[externals]/react-dom [external] (react-dom, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("react-dom", () => require("react-dom"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/pages-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/pages-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/pages-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/pages-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[project]/src/data.js [ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// src/data/navbarData.js
__turbopack_context__.s([
    "applicantAutoFillData",
    ()=>applicantAutoFillData,
    "applicantData",
    ()=>applicantData,
    "applicantFields",
    ()=>applicantFields,
    "bookingData",
    ()=>bookingData,
    "bookingProjects",
    ()=>bookingProjects,
    "coApplicantFields",
    ()=>coApplicantFields,
    "homePageData",
    ()=>homePageData,
    "navbarData",
    ()=>navbarData
]);
const navbarData = {
    logo: {
        src: "/images/logo.png",
        link: "/",
        alt: "Navayan Logo"
    },
    disclaimerlinks: {
        text: "Disclaimer",
        href: "/disclaimer"
    },
    report_button: {
        text: "Report an Issue"
    }
};
const homePageData = {
    banner: {
        image: "/images/home1.png",
        alt: "A happy family jumping for joy in a park"
    },
    heading: "Available Projects",
    button: {
        text: "Add Booking",
        link: "/booking"
    },
    projects: [
        {
            projectName: "Navayan's Capital Park",
            total: 150,
            image: "/images/project_card.png",
            available: 35,
            onHold: 20,
            booked: 10
        },
        {
            projectName: "Navayan's West Gate",
            total: 150,
            image: "/images/project_card.png",
            available: 35,
            onHold: 20,
            booked: 10
        },
        {
            projectName: "Navayan's East Enclave",
            total: 200,
            image: "/images/project_card.png",
            available: 60,
            onHold: 25,
            booked: 15
        },
        {
            projectName: "Navayan's Capital Park",
            total: 150,
            image: "/images/project_card.png",
            available: 35,
            onHold: 20,
            booked: 10
        },
        {
            projectName: "Navayan's West Gate",
            total: 150,
            image: "/images/project_card.png",
            available: 35,
            onHold: 20,
            booked: 10
        },
        {
            projectName: "Navayan's East Enclave",
            total: 200,
            image: "/images/project_card.png",
            available: 60,
            onHold: 25,
            booked: 15
        }
    ]
};
const bookingData = {
    heading: "NEW BOOKING",
    inventoryHeading: "Inventory",
    searchPlaceholder: "Search unit",
    projects: [
        {
            projectName: "Navayan's Capital Park",
            project_subtitle: "Property Details",
            total: 150,
            image: "/images/project_card.png",
            available: 35,
            onHold: 20,
            booked: 10
        }
    ],
    table: {
        kycTable: false,
        BookingTableData: [
            {
                sn: 1,
                unitNo: "S1",
                plotSize: "1500 sq.ft.",
                plotFacing: "North",
                plc: "Garden",
                cost: "₹ 7,50,000",
                addCost: "₹ 50,000",
                status: "Available",
                booked: false
            },
            {
                sn: 1,
                unitNo: "S1",
                plotSize: "1500 sq.ft.",
                plotFacing: "North",
                plc: "Garden",
                cost: "₹ 7,50,000",
                addCost: "₹ 50,000",
                status: "Available",
                booked: false
            },
            {
                sn: 2,
                unitNo: "S2",
                plotSize: "1000 sq.ft.",
                plotFacing: "East",
                plc: "Corner",
                cost: "₹ 5,00,000",
                addCost: "₹ 50,000",
                status: "Booked",
                booked: true
            },
            {
                sn: 2,
                unitNo: "S2",
                plotSize: "1000 sq.ft.",
                plotFacing: "East",
                plc: "Corner",
                cost: "₹ 5,00,000",
                addCost: "₹ 50,000",
                status: "Booked",
                booked: true
            },
            {
                sn: 2,
                unitNo: "S2",
                plotSize: "1000 sq.ft.",
                plotFacing: "East",
                plc: "Corner",
                cost: "₹ 5,00,000",
                addCost: "₹ 50,000",
                status: "Booked",
                booked: true
            },
            {
                sn: 2,
                unitNo: "S2",
                plotSize: "1000 sq.ft.",
                plotFacing: "East",
                plc: "Corner",
                cost: "₹ 5,00,000",
                addCost: "₹ 50,000",
                status: "Booked",
                booked: true
            },
            {
                sn: 1,
                unitNo: "S1",
                plotSize: "1500 sq.ft.",
                plotFacing: "North",
                plc: "Garden",
                cost: "₹ 7,50,000",
                addCost: "₹ 50,000",
                status: "Available",
                booked: false
            },
            {
                sn: 2,
                unitNo: "S2",
                plotSize: "1000 sq.ft.",
                plotFacing: "East",
                plc: "Corner",
                cost: "₹ 5,00,000",
                addCost: "₹ 50,000",
                status: "Booked",
                booked: true
            },
            {
                sn: 2,
                unitNo: "S2",
                plotSize: "1000 sq.ft.",
                plotFacing: "East",
                plc: "Corner",
                cost: "₹ 5,00,000",
                addCost: "₹ 50,000",
                status: "Booked",
                booked: true
            },
            {
                sn: 1,
                unitNo: "S1",
                plotSize: "1500 sq.ft.",
                plotFacing: "North",
                plc: "Garden",
                cost: "₹ 7,50,000",
                addCost: "₹ 50,000",
                status: "Available",
                booked: false
            },
            {
                sn: 1,
                unitNo: "S1",
                plotSize: "1500 sq.ft.",
                plotFacing: "North",
                plc: "Garden",
                cost: "₹ 7,50,000",
                addCost: "₹ 50,000",
                status: "Available",
                booked: false
            }
        ]
    }
};
const bookingProjects = [
    {
        projectName: "Navayan's Capital Park",
        total: 150,
        available: 35,
        onHold: 20,
        booked: 10
    }
];
const applicantFields = [
    {
        name: "applicantName",
        placeholder: "Full Name of Applicant",
        type: "text"
    },
    {
        name: "applicantCof",
        placeholder: "C/o of",
        type: "text"
    },
    {
        name: "applicantPhone",
        placeholder: "Phone No. of Applicant",
        type: "tel"
    },
    {
        name: "applicantAdditionalPhone",
        placeholder: "Additional No. of Applicant",
        type: "tel"
    },
    {
        name: "applicantEmail",
        placeholder: "Email Id of Applicant",
        type: "email"
    },
    {
        name: "applicantAddress",
        placeholder: "Permanent Address of Applicant",
        type: "textarea"
    },
    {
        name: "applicantAadhar",
        placeholder: "Aadhar No. of Applicant",
        type: "text"
    },
    {
        name: "applicantPan",
        placeholder: "PAN No. of Applicant",
        type: "text"
    },
    {
        name: "applicantDob",
        placeholder: "Date of Birth",
        type: "date"
    },
    {
        name: "applicantProfession",
        placeholder: "Profession of Applicant",
        type: "text"
    }
];
const coApplicantFields = [
    {
        name: "coApplicantName",
        placeholder: "Full Name",
        type: "text"
    },
    {
        name: "coApplicantCof",
        placeholder: "C/o of",
        type: "text"
    },
    {
        name: "coApplicantPhone",
        placeholder: "Phone No.",
        type: "tel"
    },
    {
        name: "coApplicantAdditionalPhone",
        placeholder: "Additional No.",
        type: "tel"
    },
    {
        name: "coApplicantEmail",
        placeholder: "Email Id",
        type: "email"
    },
    {
        name: "coApplicantAddress",
        placeholder: "Permanent Address",
        type: "textarea"
    },
    {
        name: "coApplicantAadhar",
        placeholder: "Aadhar No.",
        type: "text"
    },
    {
        name: "coApplicantPan",
        placeholder: "PAN No.",
        type: "text"
    },
    {
        name: "coApplicantDob",
        placeholder: "Date of Birth",
        type: "date"
    },
    {
        name: "coApplicantProfession",
        placeholder: "Profession",
        type: "text"
    }
];
const applicantData = {
    "Full Name of Applicant": "Example Name",
    "C/o of": "Example Text",
    "Phone No. of Applicant": "7895289625",
    "Additional No. of Applicant": "2368896488",
    "Email Id of Applicant": "Example@gmail.com",
    "Permanent Address of Applicant": "123, this is the example address, city name, state, pincode et cetera",
    "Aadhar No. of Applicant": "85598568925745852",
    "PAN No. of Applicant": "HBUBB8857",
    DOB: "08/11/1990",
    "Profession of Applicant": "Example Text"
};
const applicantAutoFillData = {
    applicantAadhar: "496895208976",
    applicantAdditionalPhone: "8107545771",
    applicantAddress: "hello world",
    applicantCof: "abcd",
    applicantDob: "2025-09-18",
    applicantEmail: "abcd@gmail.com",
    applicantName: "sonu kumar saini",
    applicantPan: "56Ad67HJ",
    applicantPhone: "08107545771",
    applicantProfession: "acbd"
};
}),
"[project]/src/components/header/Navbar.jsx [ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/link.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react [external] (react, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/data.js [ssr] (ecmascript)");
;
;
;
;
;
const Navbar = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["memo"])(()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("section", {
        className: "fixed top-0 left-0 w-full bg-white shadow-md z-50",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("header", {
            className: "w-full max-w-screen-2xl mx-auto flex items-center h-[85px] justify-between p-4 2xl:p-0",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                    href: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["navbarData"]?.logo?.link || "/",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                        className: "flex flex-col gap-1",
                        children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["navbarData"]?.logo?.src ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                            src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["navbarData"]?.logo?.src || "/images/default-logo.png",
                            width: 1200,
                            height: 1000,
                            quality: 95,
                            alt: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["navbarData"]?.logo?.alt,
                            priority: true,
                            className: "md:w-56 w-40 h-full object-contain"
                        }, void 0, false, {
                            fileName: "[project]/src/components/header/Navbar.jsx",
                            lineNumber: 13,
                            columnNumber: 15
                        }, ("TURBOPACK compile-time value", void 0)) : null
                    }, void 0, false, {
                        fileName: "[project]/src/components/header/Navbar.jsx",
                        lineNumber: 11,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/src/components/header/Navbar.jsx",
                    lineNumber: 10,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                    className: "flex items-center space-x-10",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                            href: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["navbarData"]?.disclaimerlinks?.link || "#",
                            className: "text-sky-700 text-lg font-medium leading-tight md:block hidden",
                            children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["navbarData"]?.disclaimerlinks?.text
                        }, void 0, false, {
                            fileName: "[project]/src/components/header/Navbar.jsx",
                            lineNumber: 26,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("button", {
                            className: "py-3 md:px-6 px-4 bg-[#066FA9] rounded-lg text-white text-sm font-medium font-['Inter'] leading-tight",
                            children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["navbarData"]?.report_button?.text
                        }, void 0, false, {
                            fileName: "[project]/src/components/header/Navbar.jsx",
                            lineNumber: 32,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/header/Navbar.jsx",
                    lineNumber: 25,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/header/Navbar.jsx",
            lineNumber: 9,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/components/header/Navbar.jsx",
        lineNumber: 8,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
});
Navbar.displayName = "Navbar";
const __TURBOPACK__default__export__ = Navbar;
}),
"[externals]/@studio-freight/lenis [external] (@studio-freight/lenis, esm_import)", ((__turbopack_context__) => {
"use strict";

return __turbopack_context__.a(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {

const mod = await __turbopack_context__.y("@studio-freight/lenis");

__turbopack_context__.n(mod);
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, true);}),
"[externals]/fs [external] (fs, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("fs", () => require("fs"));

module.exports = mod;
}),
"[externals]/stream [external] (stream, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("stream", () => require("stream"));

module.exports = mod;
}),
"[externals]/zlib [external] (zlib, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("zlib", () => require("zlib"));

module.exports = mod;
}),
"[project]/src/components/comman/ScrollToTop.jsx [ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ScrollToTop
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react [external] (react, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$router$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/router.js [ssr] (ecmascript)");
"use client";
;
;
function ScrollToTop() {
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$router$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useEffect"])(()=>{
        if ("scrollRestoration" in window.history) {
            window.history.scrollRestoration = "manual"; // Disable default behavior
        }
        const handleRouteChange = ()=>{
            setTimeout(()=>{
                window.scrollTo({
                    top: 0,
                    left: 0,
                    behavior: "auto"
                }); // Force scroll to top
            }, 50); // Slight delay to ensure page content is loaded
        };
        // Trigger on initial load
        handleRouteChange();
        // Trigger on navigation
        router.events.on("routeChangeComplete", handleRouteChange);
        return ()=>{
            router.events.off("routeChangeComplete", handleRouteChange);
        };
    }, [
        router
    ]);
    return null;
}
}),
"[project]/src/pages/_app.js [ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

return __turbopack_context__.a(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {

__turbopack_context__.s([
    "default",
    ()=>App
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$header$2f$Navbar$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/header/Navbar.jsx [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react [external] (react, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f40$studio$2d$freight$2f$lenis__$5b$external$5d$__$2840$studio$2d$freight$2f$lenis$2c$__esm_import$29$__ = __turbopack_context__.i("[externals]/@studio-freight/lenis [external] (@studio-freight/lenis, esm_import)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$comman$2f$ScrollToTop$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/comman/ScrollToTop.jsx [ssr] (ecmascript)");
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__imported__module__$5b$externals$5d2f40$studio$2d$freight$2f$lenis__$5b$external$5d$__$2840$studio$2d$freight$2f$lenis$2c$__esm_import$29$__
]);
[__TURBOPACK__imported__module__$5b$externals$5d2f40$studio$2d$freight$2f$lenis__$5b$external$5d$__$2840$studio$2d$freight$2f$lenis$2c$__esm_import$29$__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__;
"use client";
;
;
;
;
;
;
function App({ Component, pageProps }) {
    (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useEffect"])(()=>{
        const lenis = new __TURBOPACK__imported__module__$5b$externals$5d2f40$studio$2d$freight$2f$lenis__$5b$external$5d$__$2840$studio$2d$freight$2f$lenis$2c$__esm_import$29$__["default"]({
            duration: 1.2,
            smooth: true
        });
        function raf(time) {
            lenis.raf(time);
            requestAnimationFrame(raf);
        }
        requestAnimationFrame(raf);
        return ()=>lenis.destroy();
    }, []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$header$2f$Navbar$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/src/pages/_app.js",
                lineNumber: 22,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$comman$2f$ScrollToTop$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/src/pages/_app.js",
                lineNumber: 23,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("main", {
                className: "pt-[40px] bg-[#e9e9e9]",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(Component, {
                    ...pageProps
                }, void 0, false, {
                    fileName: "[project]/src/pages/_app.js",
                    lineNumber: 25,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/pages/_app.js",
                lineNumber: 24,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/pages/_app.js",
        lineNumber: 21,
        columnNumber: 5
    }, this);
}
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__06a3dce6._.js.map