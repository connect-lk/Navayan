module.exports = [
"[project]/src/data.js [ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "applicantData",
    ()=>applicantData,
    "applicantFields",
    ()=>applicantFields,
    "bookingProjects",
    ()=>bookingProjects,
    "coApplicantFields",
    ()=>coApplicantFields,
    "projects",
    ()=>projects,
    "tableData",
    ()=>tableData
]);
const tableData = [
    {
        sn: 1,
        unitNo: "S1",
        plotSize: "1500 sq.ft.",
        plotFacing: "North",
        plc: "Garden",
        cost: "₹ 7,50,000",
        addCost: "₹ 50,000",
        status: "Available",
        booked: false
    },
    {
        sn: 1,
        unitNo: "S1",
        plotSize: "1500 sq.ft.",
        plotFacing: "North",
        plc: "Garden",
        cost: "₹ 7,50,000",
        addCost: "₹ 50,000",
        status: "Available",
        booked: false
    },
    {
        sn: 2,
        unitNo: "S2",
        plotSize: "1000 sq.ft.",
        plotFacing: "East",
        plc: "Corner",
        cost: "₹ 5,00,000",
        addCost: "₹ 50,000",
        status: "Booked",
        booked: true
    },
    {
        sn: 2,
        unitNo: "S2",
        plotSize: "1000 sq.ft.",
        plotFacing: "East",
        plc: "Corner",
        cost: "₹ 5,00,000",
        addCost: "₹ 50,000",
        status: "Booked",
        booked: true
    },
    {
        sn: 2,
        unitNo: "S2",
        plotSize: "1000 sq.ft.",
        plotFacing: "East",
        plc: "Corner",
        cost: "₹ 5,00,000",
        addCost: "₹ 50,000",
        status: "Booked",
        booked: true
    },
    {
        sn: 2,
        unitNo: "S2",
        plotSize: "1000 sq.ft.",
        plotFacing: "East",
        plc: "Corner",
        cost: "₹ 5,00,000",
        addCost: "₹ 50,000",
        status: "Booked",
        booked: true
    },
    {
        sn: 1,
        unitNo: "S1",
        plotSize: "1500 sq.ft.",
        plotFacing: "North",
        plc: "Garden",
        cost: "₹ 7,50,000",
        addCost: "₹ 50,000",
        status: "Available",
        booked: false
    },
    {
        sn: 2,
        unitNo: "S2",
        plotSize: "1000 sq.ft.",
        plotFacing: "East",
        plc: "Corner",
        cost: "₹ 5,00,000",
        addCost: "₹ 50,000",
        status: "Booked",
        booked: true
    },
    {
        sn: 2,
        unitNo: "S2",
        plotSize: "1000 sq.ft.",
        plotFacing: "East",
        plc: "Corner",
        cost: "₹ 5,00,000",
        addCost: "₹ 50,000",
        status: "Booked",
        booked: true
    },
    {
        sn: 1,
        unitNo: "S1",
        plotSize: "1500 sq.ft.",
        plotFacing: "North",
        plc: "Garden",
        cost: "₹ 7,50,000",
        addCost: "₹ 50,000",
        status: "Available",
        booked: false
    },
    {
        sn: 1,
        unitNo: "S1",
        plotSize: "1500 sq.ft.",
        plotFacing: "North",
        plc: "Garden",
        cost: "₹ 7,50,000",
        addCost: "₹ 50,000",
        status: "Available",
        booked: false
    }
];
const projects = [
    {
        projectName: "Navayan's Capital Park",
        total: 150,
        available: 35,
        onHold: 20,
        booked: 10
    },
    {
        projectName: "Navayan's West Gate",
        total: 150,
        available: 35,
        onHold: 20,
        booked: 10
    },
    {
        projectName: "Navayan's East Enclave",
        total: 200,
        available: 60,
        onHold: 25,
        booked: 15
    },
    {
        projectName: "Navayan's Capital Park",
        total: 150,
        available: 35,
        onHold: 20,
        booked: 10
    },
    {
        projectName: "Navayan's West Gate",
        total: 150,
        available: 35,
        onHold: 20,
        booked: 10
    },
    {
        projectName: "Navayan's East Enclave",
        total: 200,
        available: 60,
        onHold: 25,
        booked: 15
    }
];
const bookingProjects = [
    {
        projectName: "Navayan's Capital Park",
        total: 150,
        available: 35,
        onHold: 20,
        booked: 10
    }
];
const applicantFields = [
    {
        name: "applicantName",
        placeholder: "Full Name of Applicant",
        type: "text"
    },
    {
        name: "applicantCof",
        placeholder: "C/o of",
        type: "text"
    },
    {
        name: "applicantPhone",
        placeholder: "Phone No. of Applicant",
        type: "tel"
    },
    {
        name: "applicantAdditionalPhone",
        placeholder: "Additional No. of Applicant",
        type: "tel"
    },
    {
        name: "applicantEmail",
        placeholder: "Email Id of Applicant",
        type: "email"
    },
    {
        name: "applicantAddress",
        placeholder: "Permanent Address of Applicant",
        type: "textarea"
    },
    {
        name: "applicantAadhar",
        placeholder: "Aadhar No. of Applicant",
        type: "text"
    },
    {
        name: "applicantPan",
        placeholder: "PAN No. of Applicant",
        type: "text"
    },
    {
        name: "applicantDob",
        placeholder: "Date of Birth",
        type: "date"
    },
    {
        name: "applicantProfession",
        placeholder: "Profession of Applicant",
        type: "text"
    }
];
const coApplicantFields = [
    {
        name: "coApplicantName",
        placeholder: "Full Name",
        type: "text"
    },
    {
        name: "coApplicantCof",
        placeholder: "C/o of",
        type: "text"
    },
    {
        name: "coApplicantPhone",
        placeholder: "Phone No.",
        type: "tel"
    },
    {
        name: "coApplicantAdditionalPhone",
        placeholder: "Additional No.",
        type: "tel"
    },
    {
        name: "coApplicantEmail",
        placeholder: "Email Id",
        type: "email"
    },
    {
        name: "coApplicantAddress",
        placeholder: "Permanent Address",
        type: "textarea"
    },
    {
        name: "coApplicantAadhar",
        placeholder: "Aadhar No.",
        type: "text"
    },
    {
        name: "coApplicantPan",
        placeholder: "PAN No.",
        type: "text"
    },
    {
        name: "coApplicantDob",
        placeholder: "Date of Birth",
        type: "date"
    },
    {
        name: "coApplicantProfession",
        placeholder: "Profession",
        type: "text"
    }
];
const applicantData = {
    "Full Name of Applicant": "Example Name",
    "C/o of": "Example Text",
    "Phone No. of Applicant": "7895289625",
    "Additional No. of Applicant": "2368896488",
    "Email Id of Applicant": "Example@gmail.com",
    "Permanent Address of Applicant": "123, this is the example address, city name, state, pincode et cetera",
    "Aadhar No. of Applicant": "85598568925745852",
    "PAN No. of Applicant": "HBUBB8857",
    "DOB": "08/11/1990",
    "Profession of Applicant": "Example Text"
};
}),
"[externals]/fs [external] (fs, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("fs", () => require("fs"));

module.exports = mod;
}),
"[externals]/stream [external] (stream, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("stream", () => require("stream"));

module.exports = mod;
}),
"[externals]/zlib [external] (zlib, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("zlib", () => require("zlib"));

module.exports = mod;
}),
"[project]/src/components/comman/InventoryTable.jsx [ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react [external] (react, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/data.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$router$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/router.js [ssr] (ecmascript)");
;
;
;
;
const InventoryTable = ({ kycTable })=>{
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$router$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
        className: `bg-white rounded-lg  min-h-auto  ${kycTable === "kycTable" ? "shadow-sm" : "shadow-sm"}`,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
            className: `rounded-lg overflow-hidden ${kycTable === "kycTable" ? "bg-gray-100 " : "bg-gray-100  "}  `,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                className: "overflow-x-auto",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("table", {
                    className: "w-full table-auto border-collapse  whitespace-nowrap",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("thead", {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("tr", {
                                className: "bg-[#f9fafb] border-b border-gray-200 text-[#6B7280] text-sm xl:text-[15px]",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("th", {
                                        className: "font-semibold xl:p-4 p-3 text-center ",
                                        children: "SN."
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                        lineNumber: 23,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("th", {
                                        className: "font-semibold xl:p-4 p-3 text-center",
                                        children: "UNIT NO."
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                        lineNumber: 24,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("th", {
                                        className: "font-semibold xl:p-4 p-3 text-center",
                                        children: "PLOT SIZE"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                        lineNumber: 27,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("th", {
                                        className: "font-semibold xl:p-4 p-3 text-center",
                                        children: "PLOT FACING"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                        lineNumber: 30,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("th", {
                                        className: "font-semibold xl:p-4 p-3 text-center",
                                        children: "PLC"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                        lineNumber: 33,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("th", {
                                        className: "font-semibold xl:p-4 p-3 text-center",
                                        children: "COST"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                        lineNumber: 34,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("th", {
                                        className: "font-semibold xl:p-4 p-3 text-center",
                                        children: "ADD COST"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                        lineNumber: 35,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("th", {
                                        className: "font-semibold xl:p-4 p-3 text-center",
                                        children: "STATUS"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                        lineNumber: 38,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    kycTable === "kycTable" ? null : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("th", {
                                        className: "font-semibold xl:p-4 p-3 text-center  ",
                                        children: "BOOK"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                        lineNumber: 40,
                                        columnNumber: 19
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                lineNumber: 22,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/src/components/comman/InventoryTable.jsx",
                            lineNumber: 21,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("tbody", {
                            className: "divide-y divide-gray-200",
                            children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["tableData"]?.map((row, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("tr", {
                                    className: "bg-white hover:bg-gray-50 transition-colors duration-200 text-sm text-[#6B7280] md:text-base",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("td", {
                                            className: "xl:p-4 p-3 text-center  ",
                                            children: row?.sn
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                            lineNumber: 52,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("td", {
                                            className: "xl:p-4 p-3 text-center",
                                            children: row?.unitNo
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                            lineNumber: 53,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("td", {
                                            className: "xl:p-4 p-3 text-center",
                                            children: row?.plotSize
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                            lineNumber: 54,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("td", {
                                            className: "xl:p-4 p-3 text-center",
                                            children: row?.plotFacing
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                            lineNumber: 55,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("td", {
                                            className: "xl:p-4 p-3 text-center",
                                            children: row?.plc
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                            lineNumber: 56,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("td", {
                                            className: "xl:p-4 p-3 text-center",
                                            children: row?.cost
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                            lineNumber: 57,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("td", {
                                            className: "xl:p-4 p-3 text-center",
                                            children: row?.addCost
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                            lineNumber: 58,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("td", {
                                            className: "xl:p-4 p-3 text-center",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                                                className: `px-2.5 py-1.5 rounded-sm text-sm font-semibold ${row.status === "Available" ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"}`,
                                                children: row?.status
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                                lineNumber: 60,
                                                columnNumber: 21
                                            }, ("TURBOPACK compile-time value", void 0))
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                            lineNumber: 59,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        kycTable === "kycTable" ? null : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("td", {
                                            className: "p-4 text-center ",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("button", {
                                                onClick: ()=>router.push("/kyc"),
                                                className: `font-semibold px-4 py-2 text-[14px] rounded-md cursor-pointer w-fit transition-all duration-300 ${row?.booked ? "bg-[#D1D5DB] text-[#4B5563] cursor-not-allowed" : "bg-[#066fa9] text-white"}`,
                                                disabled: row?.booked,
                                                children: row?.booked ? "Booked" : "Book Now"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                                lineNumber: 72,
                                                columnNumber: 23
                                            }, ("TURBOPACK compile-time value", void 0))
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                            lineNumber: 71,
                                            columnNumber: 21
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, index, true, {
                                    fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                    lineNumber: 48,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0)))
                        }, void 0, false, {
                            fileName: "[project]/src/components/comman/InventoryTable.jsx",
                            lineNumber: 46,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/comman/InventoryTable.jsx",
                    lineNumber: 20,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/components/comman/InventoryTable.jsx",
                lineNumber: 19,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/src/components/comman/InventoryTable.jsx",
            lineNumber: 14,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/components/comman/InventoryTable.jsx",
        lineNumber: 9,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
const __TURBOPACK__default__export__ = InventoryTable;
}),
"[externals]/formik [external] (formik, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("formik", () => require("formik"));

module.exports = mod;
}),
"[externals]/yup [external] (yup, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("yup", () => require("yup"));

module.exports = mod;
}),
"[project]/src/components/comman/KYCForm.jsx [ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$formik__$5b$external$5d$__$28$formik$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/formik [external] (formik, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$yup__$5b$external$5d$__$28$yup$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/yup [external] (yup, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/data.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$hi2$2f$index$2e$mjs__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/hi2/index.mjs [ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
// Build Yup validation dynamically based on fields
const buildValidationSchema = ()=>{
    const schemaShape = {};
    [
        ...__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["applicantFields"],
        ...__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["coApplicantFields"]
    ].forEach((field)=>{
        if (field.type === "email") {
            schemaShape[field.name] = __TURBOPACK__imported__module__$5b$externals$5d2f$yup__$5b$external$5d$__$28$yup$2c$__cjs$29$__["string"]().email("Invalid email").required("Required");
        } else {
            schemaShape[field.name] = __TURBOPACK__imported__module__$5b$externals$5d2f$yup__$5b$external$5d$__$28$yup$2c$__cjs$29$__["string"]().required("Required");
        }
    });
    schemaShape["termsAccepted"] = __TURBOPACK__imported__module__$5b$externals$5d2f$yup__$5b$external$5d$__$28$yup$2c$__cjs$29$__["bool"]().oneOf([
        true
    ], "You must accept the terms");
    return __TURBOPACK__imported__module__$5b$externals$5d2f$yup__$5b$external$5d$__$28$yup$2c$__cjs$29$__["object"]().shape(schemaShape);
};
const initialValues = {};
[
    ...__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["applicantFields"],
    ...__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["coApplicantFields"]
].forEach((field)=>{
    initialValues[field.name] = "";
});
initialValues["termsAccepted"] = false;
const KYCForm = ({ handleNextStep })=>{
    const validationSchema = buildValidationSchema();
    const handleSubmit = (values)=>{
        console.log("Form Data:", values);
        handleNextStep();
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
        className: "py-4",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$externals$5d2f$formik__$5b$external$5d$__$28$formik$2c$__cjs$29$__["Formik"], {
            initialValues: initialValues,
            validationSchema: validationSchema,
            onSubmit: handleSubmit,
            children: ({ errors, touched })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$externals$5d2f$formik__$5b$external$5d$__$28$formik$2c$__cjs$29$__["Form"], {
                    className: "bg-white rounded-xl shadow-md 2xl:p-10 lg:p-6 md:p-4 p-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h2", {
                            className: "md:text-center text-center justify-center text-gray-800 md:text-3xl text-2xl font-bold md:mb-6 mb-3 mt-2 leading-9 ",
                            children: "Complete Your KYC"
                        }, void 0, false, {
                            fileName: "[project]/src/components/comman/KYCForm.jsx",
                            lineNumber: 53,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                            className: "grid grid-cols-1 md:grid-cols-2 gap-8",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h3", {
                                            className: "tself-stretch text-center md:text-start justify-center text-gray-700 md:text-2xl text-xl font-semibold  leading-loose md:mb-4 mb-3",
                                            children: "Name of Applicant"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/comman/KYCForm.jsx",
                                            lineNumber: 60,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                            className: "space-y-4",
                                            children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["applicantFields"].map((field)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                    children: [
                                                        field.type === "textarea" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$externals$5d2f$formik__$5b$external$5d$__$28$formik$2c$__cjs$29$__["Field"], {
                                                            as: "textarea",
                                                            name: field.name,
                                                            placeholder: field.placeholder,
                                                            className: `w-full px-4 ${field.type === "textarea" ? "h-24" : "h-auto"}  py-3  focus:outline-none focus:ring-1 focus:ring-[#066FA9] bg-white rounded-lg  outline-1 outline-offset-[-1px] outline-gray-300`
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/comman/KYCForm.jsx",
                                                            lineNumber: 67,
                                                            columnNumber: 25
                                                        }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$externals$5d2f$formik__$5b$external$5d$__$28$formik$2c$__cjs$29$__["Field"], {
                                                            type: field.type,
                                                            name: field.name,
                                                            placeholder: field.placeholder,
                                                            className: "w-full self-stretch px-3 py-3 bg-white rounded-lg  outline-1 outline-offset-[-1px] outline-gray-300 focus:outline-none focus:ring-1 focus:ring-[#066FA9]"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/comman/KYCForm.jsx",
                                                            lineNumber: 76,
                                                            columnNumber: 25
                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                        errors[field.name] && touched[field.name] && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                            className: "text-red-500 text-sm px-1 pt-1",
                                                            children: errors[field.name]
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/comman/KYCForm.jsx",
                                                            lineNumber: 84,
                                                            columnNumber: 25
                                                        }, ("TURBOPACK compile-time value", void 0))
                                                    ]
                                                }, field.name, true, {
                                                    fileName: "[project]/src/components/comman/KYCForm.jsx",
                                                    lineNumber: 65,
                                                    columnNumber: 21
                                                }, ("TURBOPACK compile-time value", void 0)))
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/comman/KYCForm.jsx",
                                            lineNumber: 63,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/comman/KYCForm.jsx",
                                    lineNumber: 59,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h3", {
                                            className: "self-stretch justify-center text-center md:text-start text-gray-700 md:text-2xl text-xl font-semibold leading-loose md:b-4 mb-3",
                                            children: "Co-Applicant Name"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/comman/KYCForm.jsx",
                                            lineNumber: 95,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                            className: "space-y-4",
                                            children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["coApplicantFields"].map((field)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                    children: [
                                                        field.type === "textarea" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$externals$5d2f$formik__$5b$external$5d$__$28$formik$2c$__cjs$29$__["Field"], {
                                                            as: "textarea",
                                                            name: field.name,
                                                            placeholder: field.placeholder,
                                                            className: ` ${field.type === "textarea" ? "h-24" : "h-auto"}  py-3 px-4 w-full focus:outline-none focus:ring-1 focus:ring-[#066FA9] bg-white rounded-lg  outline-1 outline-offset-[-1px] outline-gray-300`
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/comman/KYCForm.jsx",
                                                            lineNumber: 102,
                                                            columnNumber: 25
                                                        }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$externals$5d2f$formik__$5b$external$5d$__$28$formik$2c$__cjs$29$__["Field"], {
                                                            type: field.type,
                                                            name: field.name,
                                                            placeholder: field.placeholder,
                                                            className: "w-full self-stretch px-3 py-3 bg-white rounded-lg  outline-1 outline-offset-[-1px] outline-gray-300 focus:outline-none focus:ring-1 focus:ring-[#066FA9]"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/comman/KYCForm.jsx",
                                                            lineNumber: 111,
                                                            columnNumber: 25
                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                        errors[field.name] && touched[field.name] && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                                            className: "text-red-500 text-sm px-1 pt-1",
                                                            children: errors[field.name]
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/comman/KYCForm.jsx",
                                                            lineNumber: 119,
                                                            columnNumber: 25
                                                        }, ("TURBOPACK compile-time value", void 0))
                                                    ]
                                                }, field.name, true, {
                                                    fileName: "[project]/src/components/comman/KYCForm.jsx",
                                                    lineNumber: 100,
                                                    columnNumber: 21
                                                }, ("TURBOPACK compile-time value", void 0)))
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/comman/KYCForm.jsx",
                                            lineNumber: 98,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/comman/KYCForm.jsx",
                                    lineNumber: 94,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/comman/KYCForm.jsx",
                            lineNumber: 56,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                            className: "mt-8 flex flex-col md:flex-row md:items-center justify-between",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                    className: "flex flex-col items-start",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                            className: "flex items-start",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$externals$5d2f$formik__$5b$external$5d$__$28$formik$2c$__cjs$29$__["Field"], {
                                                    type: "checkbox",
                                                    name: "termsAccepted",
                                                    className: "mt-1 h-4 w-4 text-[#066FA9] rounded border-gray-300 focus:ring-[#066FA9]"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/comman/KYCForm.jsx",
                                                    lineNumber: 133,
                                                    columnNumber: 19
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("label", {
                                                    className: "ml-2 pr-12 block text-sm text-gray-900",
                                                    children: [
                                                        "I confirm the details are true and consent to Neoteric Properties using them for my property booking. I also confirm my Co-Applicant's consent to share their information. Please refer to our",
                                                        " ",
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("a", {
                                                            href: "#",
                                                            className: "text-[#066FA9] hover:underline",
                                                            children: "Terms & Conditions"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/comman/KYCForm.jsx",
                                                            lineNumber: 143,
                                                            columnNumber: 21
                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                        " ",
                                                        "and",
                                                        " ",
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("a", {
                                                            href: "#",
                                                            className: "text-[#066FA9] hover:underline",
                                                            children: "Privacy Policy"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/comman/KYCForm.jsx",
                                                            lineNumber: 147,
                                                            columnNumber: 21
                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                        "."
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/comman/KYCForm.jsx",
                                                    lineNumber: 138,
                                                    columnNumber: 19
                                                }, ("TURBOPACK compile-time value", void 0))
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/comman/KYCForm.jsx",
                                            lineNumber: 132,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        errors.termsAccepted && touched.termsAccepted && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                            className: "text-red-500 text-sm mt-2 md:mt-0",
                                            children: "You must accept the terms"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/comman/KYCForm.jsx",
                                            lineNumber: 155,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/comman/KYCForm.jsx",
                                    lineNumber: 131,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("button", {
                                    type: "submit",
                                    className: "mt-6 md:mt-0 bg-[#066FA9] text-white cursor-pointer font-semibold py-3 flex items-center gap-2 px-8 rounded-lg shadow-lg transition duration-200 ease-in-out transform md:hover:scale-105",
                                    children: [
                                        "Proceed",
                                        " ",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$hi2$2f$index$2e$mjs__$5b$ssr$5d$__$28$ecmascript$29$__["HiOutlineArrowSmallRight"], {
                                                className: "text-lg"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/comman/KYCForm.jsx",
                                                lineNumber: 166,
                                                columnNumber: 19
                                            }, ("TURBOPACK compile-time value", void 0))
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/comman/KYCForm.jsx",
                                            lineNumber: 165,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/comman/KYCForm.jsx",
                                    lineNumber: 160,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/comman/KYCForm.jsx",
                            lineNumber: 130,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/comman/KYCForm.jsx",
                    lineNumber: 52,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/src/components/comman/KYCForm.jsx",
            lineNumber: 46,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/components/comman/KYCForm.jsx",
        lineNumber: 45,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
const __TURBOPACK__default__export__ = KYCForm;
}),
"[project]/src/pages/kyc.jsx [ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>page
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$comman$2f$InventoryTable$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/comman/InventoryTable.jsx [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$comman$2f$KYCForm$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/comman/KYCForm.jsx [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react [external] (react, cjs)");
;
;
;
;
function page() {
    const [currentStep, setCurrentStep] = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useState"])(3);
    const handleNextStep = ()=>{
        if (currentStep < 4) {
            setCurrentStep(currentStep + 1);
        }
    };
    const steps = [
        {
            id: 1,
            name: "Select Property"
        },
        {
            id: 2,
            name: "KYC"
        },
        {
            id: 3,
            name: "Review"
        },
        {
            id: 4,
            name: "Payment"
        }
    ];
    const renderContent = ()=>{
        if (currentStep === 2) {
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                className: " ",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$comman$2f$InventoryTable$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                        kycTable: "kycTable"
                    }, void 0, false, {
                        fileName: "[project]/src/pages/kyc.jsx",
                        lineNumber: 26,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$comman$2f$KYCForm$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                        handleNextStep: handleNextStep
                    }, void 0, false, {
                        fileName: "[project]/src/pages/kyc.jsx",
                        lineNumber: 27,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/pages/kyc.jsx",
                lineNumber: 25,
                columnNumber: 9
            }, this);
        } else if (currentStep === 3) {
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                className: "",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                        className: "w-full py-6",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h1", {
                            className: "text-2xl sm:text-3xl font-bold text-gray-800 mb-4 sm:mb-0",
                            children: "Selected Property"
                        }, void 0, false, {
                            fileName: "[project]/src/pages/kyc.jsx",
                            lineNumber: 34,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/pages/kyc.jsx",
                        lineNumber: 33,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$comman$2f$InventoryTable$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                        kycTable: "kycTable"
                    }, void 0, false, {
                        fileName: "[project]/src/pages/kyc.jsx",
                        lineNumber: 38,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                        className: "w-full py-6 mt-10",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h1", {
                            className: "text-2xl sm:text-3xl font-bold text-gray-800 mb-4 sm:mb-0",
                            children: [
                                "Applicant’s Details",
                                " "
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/pages/kyc.jsx",
                            lineNumber: 40,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/pages/kyc.jsx",
                        lineNumber: 39,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/pages/kyc.jsx",
                lineNumber: 32,
                columnNumber: 9
            }, this);
        } else if (currentStep === 4) {
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                className: " ",
                children: "Payment Component"
            }, void 0, false, {
                fileName: "[project]/src/pages/kyc.jsx",
                lineNumber: 47,
                columnNumber: 14
            }, this);
        }
        return null;
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
        className: "bg-gray-100 min-h-screen overflow-auto p-4 sm:p-8",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                className: " rounded-xl  md:p-6 p-3 max-w-screen-xl mx-auto mb-16 sticky top-12 z-10",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                    className: "flex justify-between items-center",
                    children: steps?.map((step)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                            className: "flex-1 flex flex-col items-center",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                    className: `md:w-12 w-8 md:h-12 h-8 rounded-full flex items-center text-[12px] md:text-[16px] justify-center font-bold ${currentStep >= step?.id ? "border-2 border-[#066fa9] text-[#066fa9] " : "text-stone-900"} transition-colors z-50 duration-300
                  ${currentStep > step?.id ? "bg-[#066FA9]" : "bg-white "}
                  ${currentStep === step?.id ? "bg-[#066FA9]" : " text-[#066fa9]"}
                `,
                                    children: currentStep > step?.id ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("svg", {
                                        className: "md:h-6 h-4 md:w-6 w-4 text-white z-50",
                                        fill: "none",
                                        viewBox: "0 0 24 24",
                                        stroke: "currentColor",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("path", {
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            strokeWidth: 2,
                                            d: "M5 13l4 4L19 7"
                                        }, void 0, false, {
                                            fileName: "[project]/src/pages/kyc.jsx",
                                            lineNumber: 80,
                                            columnNumber: 21
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/pages/kyc.jsx",
                                        lineNumber: 74,
                                        columnNumber: 19
                                    }, this) : step?.id
                                }, void 0, false, {
                                    fileName: "[project]/src/pages/kyc.jsx",
                                    lineNumber: 59,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                    className: `mt-2 text-center xl:text-lg md:text-md text-[11px] font-medium transition-colors duration-300 ${currentStep >= step?.id ? "text-[#1C1C1C]" : "text-[#1C1C1C]"}`,
                                    children: step?.name
                                }, void 0, false, {
                                    fileName: "[project]/src/pages/kyc.jsx",
                                    lineNumber: 92,
                                    columnNumber: 15
                                }, this),
                                step?.id < steps?.length && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                    className: `absolute md:mt-6 mt-4 h-1 w-[calc(25%-20px)] transition-colors duration-300
                    ${currentStep > step?.id ? "bg-[#066FA9]" : "bg-gray-300"}
                  `,
                                    style: {
                                        left: `calc(${step?.id * 25}% - 10px)`,
                                        transform: "translateX(-50%)"
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/src/pages/kyc.jsx",
                                    lineNumber: 101,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, step?.id, true, {
                            fileName: "[project]/src/pages/kyc.jsx",
                            lineNumber: 58,
                            columnNumber: 13
                        }, this))
                }, void 0, false, {
                    fileName: "[project]/src/pages/kyc.jsx",
                    lineNumber: 56,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/pages/kyc.jsx",
                lineNumber: 55,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                className: "max-w-screen-2xl mx-auto",
                children: renderContent()
            }, void 0, false, {
                fileName: "[project]/src/pages/kyc.jsx",
                lineNumber: 116,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/pages/kyc.jsx",
        lineNumber: 54,
        columnNumber: 5
    }, this);
}
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__ea798f54._.js.map