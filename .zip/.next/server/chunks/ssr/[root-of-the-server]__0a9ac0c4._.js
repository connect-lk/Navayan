module.exports = [
"[externals]/axios [external] (axios, esm_import)", ((__turbopack_context__) => {
"use strict";

return __turbopack_context__.a(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {

const mod = await __turbopack_context__.y("axios");

__turbopack_context__.n(mod);
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, true);}),
"[project]/src/service/httpServices.js [ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

return __turbopack_context__.a(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$axios__$5b$external$5d$__$28$axios$2c$__esm_import$29$__ = __turbopack_context__.i("[externals]/axios [external] (axios, esm_import)");
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__imported__module__$5b$externals$5d2f$axios__$5b$external$5d$__$28$axios$2c$__esm_import$29$__
]);
[__TURBOPACK__imported__module__$5b$externals$5d2f$axios__$5b$external$5d$__$28$axios$2c$__esm_import$29$__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__;
;
const instance = __TURBOPACK__imported__module__$5b$externals$5d2f$axios__$5b$external$5d$__$28$axios$2c$__esm_import$29$__["default"].create({
    baseURL: "https://book.neotericproperties.in/wp-json/wp/v2",
    timeout: 120000,
    headers: {
        Accept: "application/json",
        "Content-Type": "application/json"
    }
});
const responseBody = (response)=>response.data;
const requests = {
    get: (url, config)=>instance.get(url, config).then(responseBody),
    post: (url, body, config)=>instance.post(url, body, config).then(responseBody),
    put: (url, body)=>instance.put(url, body).then(responseBody)
};
const __TURBOPACK__default__export__ = requests;
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);}),
"[project]/src/service/allPages.js [ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

return __turbopack_context__.a(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$httpServices$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/service/httpServices.js [ssr] (ecmascript)");
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$httpServices$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__
]);
[__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$httpServices$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__;
;
const AllPages = {
    properties: async ()=>{
        try {
            const timestamp = new Date().getTime(); // cache-busting
            return await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$httpServices$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"].get(`/properties?acf_format=standard&t=${timestamp}`);
        } catch (error) {
            console.error("Error fetching properties:", error.response?.data || error.message);
            throw error;
        }
    },
    inventoryList: async (id)=>{
        try {
            const timestamp = new Date().getTime(); // cache-busting
            return await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$httpServices$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"].get(`/sp_property_availability?property_id=${id}&t=${timestamp}`);
        } catch (error) {
            console.error("Error fetching property detail:", error.response?.data || error.message);
            throw error;
        }
    },
    holdFlat: async (id)=>{
        try {
            const res = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$service$2f$httpServices$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"].post(`/hold?flat_id=${id}`);
            if (res.status) {
                console.log("Flat held successfully:", res.data);
            } else {
                console.error("Failed to hold flat:", res.data, "Code:", res.code);
            }
        } catch (error) {
            console.error("Error fetching property detail:", error.response?.data || error.message);
            throw error;
        }
    }
};
const __TURBOPACK__default__export__ = AllPages;
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);}),
"[project]/src/pages/properties/[slug].js [ssr] (ecmascript)", (() => {{

throw new Error("An error occurred while generating the chunk item [project]/src/pages/properties/[slug].js [ssr] (ecmascript)\n\nCaused by:\n- CJS module can't be async.\n\nDebug info:\n- An error occurred while generating the chunk item [project]/src/pages/properties/[slug].js [ssr] (ecmascript)\n- Execution of *EcmascriptChunkItemContent::module_factory failed\n- Execution of <ModuleChunkItem as EcmascriptChunkItem>::content_with_async_module_info failed\n- Execution of EcmascriptChunkItemContent::new failed\n- CJS module can't be async.");

}}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__0a9ac0c4._.js.map