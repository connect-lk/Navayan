module.exports = [
"[externals]/fs [external] (fs, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("fs", () => require("fs"));

module.exports = mod;
}),
"[externals]/stream [external] (stream, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("stream", () => require("stream"));

module.exports = mod;
}),
"[externals]/zlib [external] (zlib, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("zlib", () => require("zlib"));

module.exports = mod;
}),
"[project]/src/components/comman/ProjectCard.jsx [ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ProjectCard",
    ()=>ProjectCard
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$router$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/router.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react [external] (react, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$go$2f$index$2e$mjs__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/go/index.mjs [ssr] (ecmascript)");
;
;
;
;
;
const ProjectCard = ({ projectName, onHold, booked, total, available })=>{
    const stats = [
        {
            label: "Total",
            value: total,
            bgColor: "bg-[#FFF4F4]",
            textColor: "text-[#8C0000]",
            valueColor: "text-[#8C0000]"
        },
        {
            label: "Available",
            value: available,
            bgColor: "bg-[#FEF3C7]",
            textColor: "text-[#78350F]",
            valueColor: "text-[#78350F]"
        },
        {
            label: "On Hold",
            value: onHold,
            bgColor: "bg-[#DBEAFE]",
            textColor: "text-[#1E3A8A]",
            valueColor: "text-[#1E3A8A]"
        },
        {
            label: "Booked",
            value: booked,
            bgColor: "bg-[#DCFCE7]",
            textColor: "text-[#14532D]",
            valueColor: "text-[#14532D]"
        }
    ];
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$router$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
        className: "bg-white p-4 rounded-2xl shadow-lg border border-gray-200 w-full mx-auto",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                src: "/images/project_card.png",
                width: 1200,
                height: 1200,
                quality: 100,
                alt: `Image of ${projectName}`,
                className: "w-full xl:h-[240px] h-[200px] rounded-xl object-cover mb-4"
            }, void 0, false, {
                fileName: "[project]/src/components/comman/ProjectCard.jsx",
                lineNumber: 46,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h3", {
                className: "justify-center text-slate-800 text-xl font-bold leading-normal mb-3",
                children: projectName
            }, void 0, false, {
                fileName: "[project]/src/components/comman/ProjectCard.jsx",
                lineNumber: 54,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                className: "grid grid-cols-2 gap-2 text-center text-sm md:text-base",
                children: stats?.map((stat, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                        className: `${stat?.bgColor} p-2 rounded-lg flex flex-row items-center justify-between px-3`,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                                className: `block font-[500]  ${stat?.textColor}`,
                                children: stat?.label
                            }, void 0, false, {
                                fileName: "[project]/src/components/comman/ProjectCard.jsx",
                                lineNumber: 63,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                                className: `block font-bold xl:text-xl lg:text-md   ${stat?.valueColor}`,
                                children: stat?.value
                            }, void 0, false, {
                                fileName: "[project]/src/components/comman/ProjectCard.jsx",
                                lineNumber: 66,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, index, true, {
                        fileName: "[project]/src/components/comman/ProjectCard.jsx",
                        lineNumber: 59,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)))
            }, void 0, false, {
                fileName: "[project]/src/components/comman/ProjectCard.jsx",
                lineNumber: 57,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("button", {
                onClick: ()=>router.push("/booking"),
                className: "mt-6 w-full py-3 text-md text-white bg-[#066FA9] rounded-xl shadow-lg cursor-pointer  transition-colors flex items-center justify-center space-x-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                        children: "Add Booking"
                    }, void 0, false, {
                        fileName: "[project]/src/components/comman/ProjectCard.jsx",
                        lineNumber: 78,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$go$2f$index$2e$mjs__$5b$ssr$5d$__$28$ecmascript$29$__["GoArrowRight"], {
                        className: "text-2xl"
                    }, void 0, false, {
                        fileName: "[project]/src/components/comman/ProjectCard.jsx",
                        lineNumber: 79,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/comman/ProjectCard.jsx",
                lineNumber: 74,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/comman/ProjectCard.jsx",
        lineNumber: 45,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
}),
"[project]/src/data.js [ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BookingTableData",
    ()=>BookingTableData,
    "KycTableData",
    ()=>KycTableData,
    "ReviewTableData",
    ()=>ReviewTableData,
    "applicantData",
    ()=>applicantData,
    "applicantFields",
    ()=>applicantFields,
    "bookingProjects",
    ()=>bookingProjects,
    "coApplicantFields",
    ()=>coApplicantFields,
    "projects",
    ()=>projects
]);
const BookingTableData = [
    {
        sn: 1,
        unitNo: "S1",
        plotSize: "1500 sq.ft.",
        plotFacing: "North",
        plc: "Garden",
        cost: "₹ 7,50,000",
        addCost: "₹ 50,000",
        status: "Available",
        booked: false
    },
    {
        sn: 1,
        unitNo: "S1",
        plotSize: "1500 sq.ft.",
        plotFacing: "North",
        plc: "Garden",
        cost: "₹ 7,50,000",
        addCost: "₹ 50,000",
        status: "Available",
        booked: false
    },
    {
        sn: 2,
        unitNo: "S2",
        plotSize: "1000 sq.ft.",
        plotFacing: "East",
        plc: "Corner",
        cost: "₹ 5,00,000",
        addCost: "₹ 50,000",
        status: "Booked",
        booked: true
    },
    {
        sn: 2,
        unitNo: "S2",
        plotSize: "1000 sq.ft.",
        plotFacing: "East",
        plc: "Corner",
        cost: "₹ 5,00,000",
        addCost: "₹ 50,000",
        status: "Booked",
        booked: true
    },
    {
        sn: 2,
        unitNo: "S2",
        plotSize: "1000 sq.ft.",
        plotFacing: "East",
        plc: "Corner",
        cost: "₹ 5,00,000",
        addCost: "₹ 50,000",
        status: "Booked",
        booked: true
    },
    {
        sn: 2,
        unitNo: "S2",
        plotSize: "1000 sq.ft.",
        plotFacing: "East",
        plc: "Corner",
        cost: "₹ 5,00,000",
        addCost: "₹ 50,000",
        status: "Booked",
        booked: true
    },
    {
        sn: 1,
        unitNo: "S1",
        plotSize: "1500 sq.ft.",
        plotFacing: "North",
        plc: "Garden",
        cost: "₹ 7,50,000",
        addCost: "₹ 50,000",
        status: "Available",
        booked: false
    },
    {
        sn: 2,
        unitNo: "S2",
        plotSize: "1000 sq.ft.",
        plotFacing: "East",
        plc: "Corner",
        cost: "₹ 5,00,000",
        addCost: "₹ 50,000",
        status: "Booked",
        booked: true
    },
    {
        sn: 2,
        unitNo: "S2",
        plotSize: "1000 sq.ft.",
        plotFacing: "East",
        plc: "Corner",
        cost: "₹ 5,00,000",
        addCost: "₹ 50,000",
        status: "Booked",
        booked: true
    },
    {
        sn: 1,
        unitNo: "S1",
        plotSize: "1500 sq.ft.",
        plotFacing: "North",
        plc: "Garden",
        cost: "₹ 7,50,000",
        addCost: "₹ 50,000",
        status: "Available",
        booked: false
    },
    {
        sn: 1,
        unitNo: "S1",
        plotSize: "1500 sq.ft.",
        plotFacing: "North",
        plc: "Garden",
        cost: "₹ 7,50,000",
        addCost: "₹ 50,000",
        status: "Available",
        booked: false
    }
];
const KycTableData = [
    {
        sn: 1,
        unitNo: "S1",
        plotSize: "1500 sq.ft.",
        plotFacing: "North",
        plc: "Garden",
        cost: "₹ 7,50,000",
        addCost: "₹ 50,000",
        status: "Available",
        booked: false
    }
];
const ReviewTableData = [
    {
        sn: 1,
        unitNo: "S1",
        plotSize: "1500 sq.ft.",
        plotFacing: "North",
        plc: "Garden",
        cost: "₹ 7,50,000",
        addCost: "₹ 50,000",
        status: "Available",
        booked: false
    }
];
const projects = [
    {
        projectName: "Navayan's Capital Park",
        total: 150,
        available: 35,
        onHold: 20,
        booked: 10
    },
    {
        projectName: "Navayan's West Gate",
        total: 150,
        available: 35,
        onHold: 20,
        booked: 10
    },
    {
        projectName: "Navayan's East Enclave",
        total: 200,
        available: 60,
        onHold: 25,
        booked: 15
    },
    {
        projectName: "Navayan's Capital Park",
        total: 150,
        available: 35,
        onHold: 20,
        booked: 10
    },
    {
        projectName: "Navayan's West Gate",
        total: 150,
        available: 35,
        onHold: 20,
        booked: 10
    },
    {
        projectName: "Navayan's East Enclave",
        total: 200,
        available: 60,
        onHold: 25,
        booked: 15
    }
];
const bookingProjects = [
    {
        projectName: "Navayan's Capital Park",
        total: 150,
        available: 35,
        onHold: 20,
        booked: 10
    }
];
const applicantFields = [
    {
        name: "applicantName",
        placeholder: "Full Name of Applicant",
        type: "text"
    },
    {
        name: "applicantCof",
        placeholder: "C/o of",
        type: "text"
    },
    {
        name: "applicantPhone",
        placeholder: "Phone No. of Applicant",
        type: "tel"
    },
    {
        name: "applicantAdditionalPhone",
        placeholder: "Additional No. of Applicant",
        type: "tel"
    },
    {
        name: "applicantEmail",
        placeholder: "Email Id of Applicant",
        type: "email"
    },
    {
        name: "applicantAddress",
        placeholder: "Permanent Address of Applicant",
        type: "textarea"
    },
    {
        name: "applicantAadhar",
        placeholder: "Aadhar No. of Applicant",
        type: "text"
    },
    {
        name: "applicantPan",
        placeholder: "PAN No. of Applicant",
        type: "text"
    },
    {
        name: "applicantDob",
        placeholder: "Date of Birth",
        type: "date"
    },
    {
        name: "applicantProfession",
        placeholder: "Profession of Applicant",
        type: "text"
    }
];
const coApplicantFields = [
    {
        name: "coApplicantName",
        placeholder: "Full Name",
        type: "text"
    },
    {
        name: "coApplicantCof",
        placeholder: "C/o of",
        type: "text"
    },
    {
        name: "coApplicantPhone",
        placeholder: "Phone No.",
        type: "tel"
    },
    {
        name: "coApplicantAdditionalPhone",
        placeholder: "Additional No.",
        type: "tel"
    },
    {
        name: "coApplicantEmail",
        placeholder: "Email Id",
        type: "email"
    },
    {
        name: "coApplicantAddress",
        placeholder: "Permanent Address",
        type: "textarea"
    },
    {
        name: "coApplicantAadhar",
        placeholder: "Aadhar No.",
        type: "text"
    },
    {
        name: "coApplicantPan",
        placeholder: "PAN No.",
        type: "text"
    },
    {
        name: "coApplicantDob",
        placeholder: "Date of Birth",
        type: "date"
    },
    {
        name: "coApplicantProfession",
        placeholder: "Profession",
        type: "text"
    }
];
const applicantData = {
    "Full Name of Applicant": "Example Name",
    "C/o of": "Example Text",
    "Phone No. of Applicant": "7895289625",
    "Additional No. of Applicant": "2368896488",
    "Email Id of Applicant": "Example@gmail.com",
    "Permanent Address of Applicant": "123, this is the example address, city name, state, pincode et cetera",
    "Aadhar No. of Applicant": "85598568925745852",
    "PAN No. of Applicant": "HBUBB8857",
    DOB: "08/11/1990",
    "Profession of Applicant": "Example Text"
};
}),
"[project]/src/pages/index.jsx [ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$comman$2f$ProjectCard$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/comman/ProjectCard.jsx [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react [external] (react, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/data.js [ssr] (ecmascript)");
;
;
;
;
;
const Home = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
        className: "max-w-screen-2xl mx-auto pb-16 px-6 md:px-8 lg:px-12 2xl:px-0",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                className: "relative w-full overflow-hidden mt-20 rounded-xl",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                    src: "/images/home1.png",
                    alt: "A happy family jumping for joy in a park",
                    width: 1200,
                    height: 400,
                    quality: 100,
                    className: "w-full lg:h-auto md:h-[350px] h-[200px] lg:object-contain object-cover"
                }, void 0, false, {
                    fileName: "[project]/src/pages/index.jsx",
                    lineNumber: 9,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/pages/index.jsx",
                lineNumber: 8,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                className: "max-w-screen-2xl mx-auto md:pt-12",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h2", {
                        className: "text-center justify-start text-neutral-900 md:text-[28px] text-2xl font-bold  leading-7 my-8",
                        children: "Available Projects"
                    }, void 0, false, {
                        fileName: "[project]/src/pages/index.jsx",
                        lineNumber: 19,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                        className: " grid lg:grid-cols-3 md:grid-cols-2 grid-cols-1  items-center md:items-stretch justify-center xl:gap-8 gap-4",
                        children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["projects"].map((project, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$comman$2f$ProjectCard$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["ProjectCard"], {
                                projectName: project.projectName,
                                total: project.total,
                                available: project.available,
                                onHold: project.onHold,
                                booked: project.booked
                            }, index, false, {
                                fileName: "[project]/src/pages/index.jsx",
                                lineNumber: 24,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)))
                    }, void 0, false, {
                        fileName: "[project]/src/pages/index.jsx",
                        lineNumber: 22,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/pages/index.jsx",
                lineNumber: 18,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/pages/index.jsx",
        lineNumber: 7,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
const __TURBOPACK__default__export__ = Home;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__b49359aa._.js.map