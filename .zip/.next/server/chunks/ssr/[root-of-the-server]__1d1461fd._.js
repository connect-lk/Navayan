module.exports = [
"[project]/src/components/comman/NewBookingCard.jsx [ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "NewBookingCard",
    ()=>NewBookingCard
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react [external] (react, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [ssr] (ecmascript)");
;
;
;
const NewBookingCard = ({ projectName, onHold, booked, total, available })=>{
    const stats = [
        {
            label: "Total",
            value: total,
            bgColor: "bg-[#FFF4F4]",
            textColor: "text-[#8C0000]",
            valueColor: "text-[#8C0000]"
        },
        {
            label: "Available",
            value: available,
            bgColor: "bg-[#FEF3C7]",
            textColor: "text-[#78350F]",
            valueColor: "text-[#78350F]"
        },
        {
            label: "On Hold",
            value: onHold,
            bgColor: "bg-[#DBEAFE]",
            textColor: "text-[#1E3A8A]",
            valueColor: "text-[#1E3A8A]"
        },
        {
            label: "Booked",
            value: booked,
            bgColor: "bg-[#DCFCE7]",
            textColor: "text-[#14532D]",
            valueColor: "text-[#14532D]"
        }
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
        className: "bg-white p-4 rounded-2xl flex flex-col md:flex-row items-stretch gap-4 md:gap-8 shadow-lg border border-gray-200 w-full max-w-screen-2xl mx-auto",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                className: "flex-shrink-0 w-full md:w-1/3",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                    src: "/images/project_card.png",
                    width: 1200,
                    height: 1200,
                    quality: 95,
                    alt: `Image of ${projectName}`,
                    className: "w-full h-[210px] rounded-xl object-cover"
                }, void 0, false, {
                    fileName: "[project]/src/components/comman/NewBookingCard.jsx",
                    lineNumber: 46,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/components/comman/NewBookingCard.jsx",
                lineNumber: 45,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                className: "flex flex-col justify-between w-full md:w-2/3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                        className: "",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("p", {
                                className: "text-sm font-medium text-gray-500 mb-2",
                                children: "Property Details"
                            }, void 0, false, {
                                fileName: "[project]/src/components/comman/NewBookingCard.jsx",
                                lineNumber: 59,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h3", {
                                className: "text-xl font-bold text-[#1F2937] mb-4",
                                children: "Navayan's Capital Park"
                            }, void 0, false, {
                                fileName: "[project]/src/components/comman/NewBookingCard.jsx",
                                lineNumber: 62,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/comman/NewBookingCard.jsx",
                        lineNumber: 58,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-2 gap-2 text-center text-sm w-full md:text-base",
                        children: stats?.map((stat, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                className: `${stat?.bgColor} xl:p-3 p-2 rounded-lg flex flex-row items-center justify-between px-3`,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                                        className: `block font-medium ${stat?.textColor}`,
                                        children: stat?.label
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/comman/NewBookingCard.jsx",
                                        lineNumber: 74,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                                        className: `block font-bold text-xl ${stat?.valueColor}`,
                                        children: stat?.value
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/comman/NewBookingCard.jsx",
                                        lineNumber: 77,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, index, true, {
                                fileName: "[project]/src/components/comman/NewBookingCard.jsx",
                                lineNumber: 70,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)))
                    }, void 0, false, {
                        fileName: "[project]/src/components/comman/NewBookingCard.jsx",
                        lineNumber: 68,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/comman/NewBookingCard.jsx",
                lineNumber: 57,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/comman/NewBookingCard.jsx",
        lineNumber: 43,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
}),
"[externals]/fs [external] (fs, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("fs", () => require("fs"));

module.exports = mod;
}),
"[externals]/stream [external] (stream, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("stream", () => require("stream"));

module.exports = mod;
}),
"[externals]/zlib [external] (zlib, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("zlib", () => require("zlib"));

module.exports = mod;
}),
"[project]/src/components/comman/InventoryTable.jsx [ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react [external] (react, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$router$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/router.js [ssr] (ecmascript)");
;
;
;
const InventoryTable = ({ kycTable, tableData })=>{
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$router$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
        className: `bg-white rounded-xl  min-h-auto  ${kycTable === "kycTable" || kycTable === "ReviewTable" ? "shadow-sm" : "shadow-sm"}`,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
            className: `rounded-xl overflow-hidden ${kycTable === "kycTable" || kycTable === "ReviewTable" ? "bg-gray-100 " : "bg-gray-100  "}  `,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                className: "overflow-x-auto",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("table", {
                    className: "w-full table-auto border-collapse  whitespace-nowrap",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("thead", {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("tr", {
                                className: "bg-[#f9fafb] border-b border-gray-200 text-[#6B7280] text-sm xl:text-[15px]",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("th", {
                                        className: "font-semibold xl:p-4 p-3 text-center ",
                                        children: "SN."
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                        lineNumber: 27,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("th", {
                                        className: "font-semibold xl:p-4 p-3 text-center",
                                        children: "UNIT NO."
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                        lineNumber: 28,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("th", {
                                        className: "font-semibold xl:p-4 p-3 text-center",
                                        children: "PLOT SIZE"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                        lineNumber: 31,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("th", {
                                        className: "font-semibold xl:p-4 p-3 text-center",
                                        children: "PLOT FACING"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                        lineNumber: 34,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("th", {
                                        className: "font-semibold xl:p-4 p-3 text-center",
                                        children: "PLC"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                        lineNumber: 37,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("th", {
                                        className: "font-semibold xl:p-4 p-3 text-center",
                                        children: "COST"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                        lineNumber: 38,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("th", {
                                        className: "font-semibold xl:p-4 p-3 text-center",
                                        children: "ADD COST"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                        lineNumber: 39,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("th", {
                                        className: "font-semibold xl:p-4 p-3 text-center",
                                        children: "STATUS"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                        lineNumber: 42,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    kycTable === "kycTable" || kycTable === "ReviewTable" ? null : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("th", {
                                        className: "font-semibold xl:p-4 p-3 text-center  ",
                                        children: "BOOK"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                        lineNumber: 45,
                                        columnNumber: 19
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                lineNumber: 26,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/src/components/comman/InventoryTable.jsx",
                            lineNumber: 25,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("tbody", {
                            className: "divide-y divide-gray-200",
                            children: tableData?.map((row, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("tr", {
                                    className: "bg-white hover:bg-gray-50 transition-colors duration-200 text-sm text-[#6B7280] md:text-base",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("td", {
                                            className: "xl:p-4 p-3 text-center  ",
                                            children: row?.sn
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                            lineNumber: 57,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("td", {
                                            className: "xl:p-4 p-3 text-center",
                                            children: row?.unitNo
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                            lineNumber: 58,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("td", {
                                            className: "xl:p-4 p-3 text-center",
                                            children: row?.plotSize
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                            lineNumber: 59,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("td", {
                                            className: "xl:p-4 p-3 text-center",
                                            children: row?.plotFacing
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                            lineNumber: 60,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("td", {
                                            className: "xl:p-4 p-3 text-center",
                                            children: row?.plc
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                            lineNumber: 61,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("td", {
                                            className: "xl:p-4 p-3 text-center",
                                            children: row?.cost
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                            lineNumber: 62,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("td", {
                                            className: "xl:p-4 p-3 text-center",
                                            children: row?.addCost
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                            lineNumber: 63,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("td", {
                                            className: "xl:p-4 p-3 text-center",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                                                className: `px-2.5 py-1.5 rounded-sm text-sm font-semibold ${row.status === "Available" ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"}`,
                                                children: row?.status
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                                lineNumber: 65,
                                                columnNumber: 21
                                            }, ("TURBOPACK compile-time value", void 0))
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                            lineNumber: 64,
                                            columnNumber: 19
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        kycTable === "kycTable" || kycTable === "ReviewTable" ? null : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("td", {
                                            className: "p-4 text-center ",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("button", {
                                                onClick: ()=>router.push("/kyc"),
                                                className: `font-semibold px-4 py-2 text-[14px] rounded-md cursor-pointer w-fit transition-all duration-300 ${row?.booked ? "bg-[#D1D5DB] text-[#4B5563] cursor-not-allowed" : "bg-[#066fa9] text-white"}`,
                                                disabled: row?.booked,
                                                children: row?.booked ? "Booked" : "Book Now"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                                lineNumber: 78,
                                                columnNumber: 23
                                            }, ("TURBOPACK compile-time value", void 0))
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                            lineNumber: 77,
                                            columnNumber: 21
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, index, true, {
                                    fileName: "[project]/src/components/comman/InventoryTable.jsx",
                                    lineNumber: 53,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0)))
                        }, void 0, false, {
                            fileName: "[project]/src/components/comman/InventoryTable.jsx",
                            lineNumber: 51,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/comman/InventoryTable.jsx",
                    lineNumber: 24,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/components/comman/InventoryTable.jsx",
                lineNumber: 23,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/src/components/comman/InventoryTable.jsx",
            lineNumber: 16,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/components/comman/InventoryTable.jsx",
        lineNumber: 9,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
const __TURBOPACK__default__export__ = InventoryTable;
}),
"[project]/src/data.js [ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BookingTableData",
    ()=>BookingTableData,
    "KycTableData",
    ()=>KycTableData,
    "ReviewTableData",
    ()=>ReviewTableData,
    "applicantData",
    ()=>applicantData,
    "applicantFields",
    ()=>applicantFields,
    "bookingProjects",
    ()=>bookingProjects,
    "coApplicantFields",
    ()=>coApplicantFields,
    "projects",
    ()=>projects
]);
const BookingTableData = [
    {
        sn: 1,
        unitNo: "S1",
        plotSize: "1500 sq.ft.",
        plotFacing: "North",
        plc: "Garden",
        cost: "₹ 7,50,000",
        addCost: "₹ 50,000",
        status: "Available",
        booked: false
    },
    {
        sn: 1,
        unitNo: "S1",
        plotSize: "1500 sq.ft.",
        plotFacing: "North",
        plc: "Garden",
        cost: "₹ 7,50,000",
        addCost: "₹ 50,000",
        status: "Available",
        booked: false
    },
    {
        sn: 2,
        unitNo: "S2",
        plotSize: "1000 sq.ft.",
        plotFacing: "East",
        plc: "Corner",
        cost: "₹ 5,00,000",
        addCost: "₹ 50,000",
        status: "Booked",
        booked: true
    },
    {
        sn: 2,
        unitNo: "S2",
        plotSize: "1000 sq.ft.",
        plotFacing: "East",
        plc: "Corner",
        cost: "₹ 5,00,000",
        addCost: "₹ 50,000",
        status: "Booked",
        booked: true
    },
    {
        sn: 2,
        unitNo: "S2",
        plotSize: "1000 sq.ft.",
        plotFacing: "East",
        plc: "Corner",
        cost: "₹ 5,00,000",
        addCost: "₹ 50,000",
        status: "Booked",
        booked: true
    },
    {
        sn: 2,
        unitNo: "S2",
        plotSize: "1000 sq.ft.",
        plotFacing: "East",
        plc: "Corner",
        cost: "₹ 5,00,000",
        addCost: "₹ 50,000",
        status: "Booked",
        booked: true
    },
    {
        sn: 1,
        unitNo: "S1",
        plotSize: "1500 sq.ft.",
        plotFacing: "North",
        plc: "Garden",
        cost: "₹ 7,50,000",
        addCost: "₹ 50,000",
        status: "Available",
        booked: false
    },
    {
        sn: 2,
        unitNo: "S2",
        plotSize: "1000 sq.ft.",
        plotFacing: "East",
        plc: "Corner",
        cost: "₹ 5,00,000",
        addCost: "₹ 50,000",
        status: "Booked",
        booked: true
    },
    {
        sn: 2,
        unitNo: "S2",
        plotSize: "1000 sq.ft.",
        plotFacing: "East",
        plc: "Corner",
        cost: "₹ 5,00,000",
        addCost: "₹ 50,000",
        status: "Booked",
        booked: true
    },
    {
        sn: 1,
        unitNo: "S1",
        plotSize: "1500 sq.ft.",
        plotFacing: "North",
        plc: "Garden",
        cost: "₹ 7,50,000",
        addCost: "₹ 50,000",
        status: "Available",
        booked: false
    },
    {
        sn: 1,
        unitNo: "S1",
        plotSize: "1500 sq.ft.",
        plotFacing: "North",
        plc: "Garden",
        cost: "₹ 7,50,000",
        addCost: "₹ 50,000",
        status: "Available",
        booked: false
    }
];
const KycTableData = [
    {
        sn: 1,
        unitNo: "S1",
        plotSize: "1500 sq.ft.",
        plotFacing: "North",
        plc: "Garden",
        cost: "₹ 7,50,000",
        addCost: "₹ 50,000",
        status: "Available",
        booked: false
    }
];
const ReviewTableData = [
    {
        sn: 1,
        unitNo: "S1",
        plotSize: "1500 sq.ft.",
        plotFacing: "North",
        plc: "Garden",
        cost: "₹ 7,50,000",
        addCost: "₹ 50,000",
        status: "Available",
        booked: false
    }
];
const projects = [
    {
        projectName: "Navayan's Capital Park",
        total: 150,
        available: 35,
        onHold: 20,
        booked: 10
    },
    {
        projectName: "Navayan's West Gate",
        total: 150,
        available: 35,
        onHold: 20,
        booked: 10
    },
    {
        projectName: "Navayan's East Enclave",
        total: 200,
        available: 60,
        onHold: 25,
        booked: 15
    },
    {
        projectName: "Navayan's Capital Park",
        total: 150,
        available: 35,
        onHold: 20,
        booked: 10
    },
    {
        projectName: "Navayan's West Gate",
        total: 150,
        available: 35,
        onHold: 20,
        booked: 10
    },
    {
        projectName: "Navayan's East Enclave",
        total: 200,
        available: 60,
        onHold: 25,
        booked: 15
    }
];
const bookingProjects = [
    {
        projectName: "Navayan's Capital Park",
        total: 150,
        available: 35,
        onHold: 20,
        booked: 10
    }
];
const applicantFields = [
    {
        name: "applicantName",
        placeholder: "Full Name of Applicant",
        type: "text"
    },
    {
        name: "applicantCof",
        placeholder: "C/o of",
        type: "text"
    },
    {
        name: "applicantPhone",
        placeholder: "Phone No. of Applicant",
        type: "tel"
    },
    {
        name: "applicantAdditionalPhone",
        placeholder: "Additional No. of Applicant",
        type: "tel"
    },
    {
        name: "applicantEmail",
        placeholder: "Email Id of Applicant",
        type: "email"
    },
    {
        name: "applicantAddress",
        placeholder: "Permanent Address of Applicant",
        type: "textarea"
    },
    {
        name: "applicantAadhar",
        placeholder: "Aadhar No. of Applicant",
        type: "text"
    },
    {
        name: "applicantPan",
        placeholder: "PAN No. of Applicant",
        type: "text"
    },
    {
        name: "applicantDob",
        placeholder: "Date of Birth",
        type: "date"
    },
    {
        name: "applicantProfession",
        placeholder: "Profession of Applicant",
        type: "text"
    }
];
const coApplicantFields = [
    {
        name: "coApplicantName",
        placeholder: "Full Name",
        type: "text"
    },
    {
        name: "coApplicantCof",
        placeholder: "C/o of",
        type: "text"
    },
    {
        name: "coApplicantPhone",
        placeholder: "Phone No.",
        type: "tel"
    },
    {
        name: "coApplicantAdditionalPhone",
        placeholder: "Additional No.",
        type: "tel"
    },
    {
        name: "coApplicantEmail",
        placeholder: "Email Id",
        type: "email"
    },
    {
        name: "coApplicantAddress",
        placeholder: "Permanent Address",
        type: "textarea"
    },
    {
        name: "coApplicantAadhar",
        placeholder: "Aadhar No.",
        type: "text"
    },
    {
        name: "coApplicantPan",
        placeholder: "PAN No.",
        type: "text"
    },
    {
        name: "coApplicantDob",
        placeholder: "Date of Birth",
        type: "date"
    },
    {
        name: "coApplicantProfession",
        placeholder: "Profession",
        type: "text"
    }
];
const applicantData = {
    "Full Name of Applicant": "Example Name",
    "C/o of": "Example Text",
    "Phone No. of Applicant": "7895289625",
    "Additional No. of Applicant": "2368896488",
    "Email Id of Applicant": "Example@gmail.com",
    "Permanent Address of Applicant": "123, this is the example address, city name, state, pincode et cetera",
    "Aadhar No. of Applicant": "85598568925745852",
    "PAN No. of Applicant": "HBUBB8857",
    DOB: "08/11/1990",
    "Profession of Applicant": "Example Text"
};
}),
"[project]/src/pages/booking.jsx [ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$comman$2f$NewBookingCard$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/comman/NewBookingCard.jsx [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$io5$2f$index$2e$mjs__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/io5/index.mjs [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react [external] (react, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$comman$2f$InventoryTable$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/comman/InventoryTable.jsx [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/data.js [ssr] (ecmascript)");
;
;
;
;
;
;
;
const page = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
        className: "max-w-screen-2xl mx-auto pb-16 px-6 md:px-8 lg:px-12 2xl:px-0",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                className: "max-w-screen-2xl mx-auto pt-12",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h2", {
                        className: "text-center justify-start text-neutral-900 md:text-3xl text-2xl font-bold  leading-7 my-8",
                        children: "NEW BOOKING"
                    }, void 0, false, {
                        fileName: "[project]/src/pages/booking.jsx",
                        lineNumber: 11,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                        className: " grid grid-cols-1 w-full  items-center md:items-stretch justify-center xl:gap-8 gap-4",
                        children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["bookingProjects"]?.map((project, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$comman$2f$NewBookingCard$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["NewBookingCard"], {
                                projectName: project?.projectName,
                                total: project?.total,
                                available: project?.available,
                                onHold: project?.onHold,
                                booked: project?.booked
                            }, index, false, {
                                fileName: "[project]/src/pages/booking.jsx",
                                lineNumber: 16,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)))
                    }, void 0, false, {
                        fileName: "[project]/src/pages/booking.jsx",
                        lineNumber: 14,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/pages/booking.jsx",
                lineNumber: 10,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                className: "w-full py-6",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                    className: "flex flex-col sm:flex-row items-center justify-between ",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("h1", {
                            className: "text-2xl md:text-[28px] font-bold text-gray-800 mb-4 sm:mb-0",
                            children: "Inventory"
                        }, void 0, false, {
                            fileName: "[project]/src/pages/booking.jsx",
                            lineNumber: 30,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                            className: "w-full sm:w-80",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                className: "relative flex items-center bg-white rounded-lg shadow-inner",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("input", {
                                        type: "text",
                                        placeholder: "Search unit",
                                        className: "w-full py-3.5 pl-4 pr-10 text-sm text-gray-700 placeholder-gray-500 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#066fa9]"
                                    }, void 0, false, {
                                        fileName: "[project]/src/pages/booking.jsx",
                                        lineNumber: 36,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$io5$2f$index$2e$mjs__$5b$ssr$5d$__$28$ecmascript$29$__["IoSearchOutline"], {
                                        className: "absolute right-3 w-5 h-5 text-gray-500"
                                    }, void 0, false, {
                                        fileName: "[project]/src/pages/booking.jsx",
                                        lineNumber: 41,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/pages/booking.jsx",
                                lineNumber: 35,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/src/pages/booking.jsx",
                            lineNumber: 34,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/pages/booking.jsx",
                    lineNumber: 29,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/pages/booking.jsx",
                lineNumber: 28,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$comman$2f$InventoryTable$2e$jsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                tableData: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$data$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["BookingTableData"]
            }, void 0, false, {
                fileName: "[project]/src/pages/booking.jsx",
                lineNumber: 46,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/pages/booking.jsx",
        lineNumber: 9,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
const __TURBOPACK__default__export__ = page;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__1d1461fd._.js.map